import React from 'react';
import { InstagramIcon } from 'lucide-react';
import { Logo } from '../Logo';

type FooterLink = {label: string;href: string;};

export interface SiteFooterProps {
  tagline?: string;
  links?: FooterLink[];
  legalLinks?: FooterLink[];
  instagramHandle?: string;
  /** Copyright year; defaults to the current year */
  year?: number;
  className?: string;
}

const DEFAULT_LINKS: FooterLink[] = [
{ label: 'Start', href: '/' },
{ label: 'Preise', href: '/preise' },
{ label: 'Rezepte', href: '/rezepte' },
{ label: 'Mietablauf', href: '/mietablauf' },
{ label: 'Über uns', href: '/ueber-uns' },
{ label: 'Kontakt', href: '/kontakt' }];


const DEFAULT_LEGAL: FooterLink[] = [
{ label: 'Impressum', href: '/impressum' },
{ label: 'Datenschutz', href: '/datenschutz' },
{ label: 'AGB', href: '/agb' }];


const linkClass =
'rounded-sm text-sm text-text transition-colors hover:text-accent focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-card';

export function SiteFooter({
  tagline = 'Mobile Bar für besondere Momente.',
  links = DEFAULT_LINKS,
  legalLinks = DEFAULT_LEGAL,
  instagramHandle = 'zumwohlmobil',
  year = new Date().getFullYear(),
  className = ''
}: SiteFooterProps) {
  return (
    <footer className={`w-full bg-card text-text ${className}`}>
      <div className="mx-auto grid w-full max-w-7xl gap-10 px-5 py-14 md:grid-cols-3 md:px-8">
        <div className="flex flex-col items-start gap-4">
          <Logo size="lg" href="/" className="[&_img]:h-24" />
          <p className="max-w-xs text-sm leading-relaxed">
            <span className="font-medium">Zum Wohl Mobil</span> – {tagline}
          </p>
          {instagramHandle &&
          <a
            href={`https://www.instagram.com/${instagramHandle}/`}
            target="_blank"
            rel="noopener noreferrer"
            className={`inline-flex items-center gap-2 ${linkClass}`}>
            
              <InstagramIcon className="h-4 w-4" strokeWidth={1.75} aria-hidden="true" />@{instagramHandle}
            </a>
          }
        </div>

        <nav aria-label="Seiten">
          <h2 className="mb-4 text-xs font-medium uppercase tracking-[0.2em]">Seiten</h2>
          <ul className="grid grid-cols-2 gap-x-6 gap-y-2 md:grid-cols-1">
            {links.map((l) =>
            <li key={l.href}>
                <a href={l.href} className={linkClass}>
                  {l.label}
                </a>
              </li>
            )}
          </ul>
        </nav>

        <nav aria-label="Rechtliches">
          <h2 className="mb-4 text-xs font-medium uppercase tracking-[0.2em]">Rechtliches</h2>
          <ul className="flex flex-col gap-2">
            {legalLinks.map((l) =>
            <li key={l.href}>
                <a href={l.href} className={linkClass}>
                  {l.label}
                </a>
              </li>
            )}
          </ul>
        </nav>
      </div>
      <div className="border-t border-wash">
        <p className="mx-auto w-full max-w-7xl px-5 py-5 text-xs text-text md:px-8">
          © {year} Zum Wohl Mobil. Alle Rechte vorbehalten.
        </p>
      </div>
    </footer>);

}