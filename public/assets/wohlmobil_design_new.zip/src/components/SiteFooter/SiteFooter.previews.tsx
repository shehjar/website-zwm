import { SiteFooter } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'SiteFooter',
  importPath: 'components/SiteFooter',
  previews: [
  {
    name: 'Default',
    description: 'Brand column, page links, legal links, copyright',
    render: () => <SiteFooter />
  },
  {
    name: 'Without Instagram',
    description: 'Instagram link hidden',
    render: () => <SiteFooter instagramHandle="" year={2026} />
  }]

};

export default previews;