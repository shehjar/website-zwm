# SiteFooter

Global footer on a pale sage (`bg-card`) surface. Three columns, which stack on mobile:
1. Logo, "Zum Wohl Mobil – Mobile Bar für besondere Momente." and an Instagram link.
2. Page links: Start, Preise, Rezepte, Mietablauf, Über uns, Kontakt.
3. Rechtliches: Impressum, Datenschutz, AGB. These pages are legally required in Germany, so always keep them.

Copyright line: "© {year} Zum Wohl Mobil. Alle Rechte vorbehalten." The year updates automatically.

## Props
| Prop | Type | Default |
|---|---|---|
| `tagline` | `string` | `'Mobile Bar für besondere Momente.'` |
| `links` / `legalLinks` | `{ label, href }[]` | see above |
| `instagramHandle` | `string` | `'zumwohlmobil'`. Pass `''` to hide it |
| `year` | `number` | current year |
| `className` | `string` | — |
