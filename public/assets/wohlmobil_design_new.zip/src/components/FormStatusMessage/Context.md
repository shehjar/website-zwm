# FormStatusMessage

Feedback banner shown above/below a form after submission. Supports success, error, info and loading states, animates in/out with framer-motion, and announces itself to screen readers (`role="alert"` for errors, `role="status"` otherwise).

## Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `status` | `'success' \| 'error' \| 'info' \| 'loading'` | — | Visual + semantic state |
| `title` | `string` | — | Bold headline |
| `message` | `ReactNode` | — | Supporting text |
| `visible` | `boolean` | `true` | Toggle with exit animation |
| `onDismiss` | `() => void` | — | Renders a close button when set |
| `action` | `ReactNode` | — | Optional action (e.g. retry button) |
| `className` | `string` | — | Extra classes (merged via tailwind-merge) |

## Usage

```tsx
import { FormStatusMessage } from 'components/FormStatusMessage'

<FormStatusMessage
  status="success"
  title="Vielen Dank!"
  message="Wir melden uns innerhalb von 24 Stunden."
/>

<FormStatusMessage
  status="error"
  title="Senden fehlgeschlagen"
  message="Bitte versuchen Sie es erneut."
  onDismiss={() => setStatus(null)}
/>
```

Use `status="loading"` while the request is in flight, then switch to `success` or `error`.
