import React, { useState } from 'react';
import { FormStatusMessage } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

function DismissibleDemo() {
  const [visible, setVisible] = useState(true);
  return (
    <div className="w-full max-w-md space-y-3">
      <FormStatusMessage
        status="success"
        title="Nachricht gesendet"
        message="Wir melden uns so schnell wie möglich bei Ihnen."
        visible={visible}
        onDismiss={() => setVisible(false)} />
      
      {!visible &&
      <button
        type="button"
        onClick={() => setVisible(true)}
        className="text-sm font-medium text-gray-700 underline">
        
          Erneut anzeigen
        </button>
      }
    </div>);

}

const previews: ComponentPreviewModule = {
  componentName: 'FormStatusMessage',
  importPath: 'components/FormStatusMessage',
  previews: [
  {
    name: 'Success',
    description: 'Shown after a successful submission',
    render: () =>
    <div className="w-full max-w-md">
          <FormStatusMessage
        status="success"
        title="Vielen Dank!"
        message="Ihre Anfrage ist bei uns eingegangen. Wir melden uns innerhalb von 24 Stunden." />
      
        </div>

  },
  {
    name: 'Error with retry',
    description: 'Submission failed, with a retry action',
    render: () =>
    <div className="w-full max-w-md">
          <FormStatusMessage
        status="error"
        title="Senden fehlgeschlagen"
        message="Bitte prüfen Sie Ihre Verbindung und versuchen Sie es erneut."
        action={
        <button
          type="button"
          className="rounded-md bg-red-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-red-700">
          
                Erneut versuchen
              </button>
        } />
      
        </div>

  },
  {
    name: 'Loading & info',
    description: 'Pending and informational states',
    render: () =>
    <div className="w-full max-w-md space-y-3">
          <FormStatusMessage status="loading" message="Wird gesendet…" />
          <FormStatusMessage
        status="info"
        message="Pflichtfelder sind mit * gekennzeichnet." />
      
        </div>

  },
  {
    name: 'Dismissible',
    description: 'Animated dismiss via onDismiss',
    render: () => <DismissibleDemo />
  }]

};

export default previews;