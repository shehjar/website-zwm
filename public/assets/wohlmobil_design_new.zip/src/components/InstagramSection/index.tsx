import React from 'react';
import { InstagramIcon } from 'lucide-react';
import { PillButton } from '../PillButton';

export type InstagramPost = {
  src: string;
  alt: string;
  /** Link to the post; defaults to the profile */
  href?: string;
};

export interface InstagramSectionProps {
  handle?: string;
  title?: string;
  text?: string;
  /** 4–6 curated images. Static on purpose — no third-party embed (DSGVO). */
  posts?: InstagramPost[];
  className?: string;
}

export function InstagramSection({
  handle = 'zumwohlmobil',
  title = 'Folge uns auf Instagram',
  text = 'Lass dich von unseren letzten Events inspirieren und wirf einen Blick hinter die Kulissen.',
  posts = [],
  className = ''
}: InstagramSectionProps) {
  const profile = `https://www.instagram.com/${handle}/`;
  const shown = posts.slice(0, 6);

  return (
    <section className={`w-full bg-background px-5 py-16 md:px-8 md:py-24 ${className}`}>
      <div className="mx-auto max-w-7xl">
        <header className="mx-auto max-w-2xl text-center">
          <h2 className="text-xl font-medium uppercase tracking-[0.18em] text-text md:text-2xl">{title}</h2>
          <p className="mt-3 text-base leading-relaxed text-text">{text}</p>
        </header>

        {shown.length > 0 ?
        <ul
          className={`mt-10 grid grid-cols-2 gap-3 md:gap-4 ${
          shown.length >= 6 ? 'md:grid-cols-3 lg:grid-cols-6' : 'md:grid-cols-4'}`
          }>
          
            {shown.map((post, i) =>
          <li key={`${post.src}-${i}`}>
                <a
              href={post.href ?? profile}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative block aspect-square overflow-hidden rounded-2xl bg-wash focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2">
              
                  <img
                src={post.src}
                alt={post.alt}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
              
                  <span className="sr-only"> – auf Instagram ansehen (öffnet in neuem Tab)</span>
                </a>
              </li>
          )}
          </ul> :

        <p className="mt-10 rounded-2xl bg-wash px-6 py-10 text-center text-sm text-muted-text">
            Hier erscheinen bald Eindrücke von unseren Events.
          </p>
        }

        <div className="mt-10 flex justify-center">
          <PillButton href={profile} target="_blank" rel="noopener noreferrer">
            <span className="inline-flex items-center gap-2 normal-case tracking-normal">
              <InstagramIcon className="h-4 w-4" aria-hidden="true" />@{handle} auf Instagram folgen
            </span>
          </PillButton>
        </div>
      </div>
    </section>);

}