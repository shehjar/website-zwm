# InstagramSection

Homepage social-proof section. It has a title, a short text, a grid of 4–6 square photos linking to Instagram, and the button "@zumwohlmobil auf Instagram folgen".

**This is a static grid on purpose.** A live feed widget loads Instagram/Meta scripts. Under German data protection law (DSGVO) that requires cookie consent before it loads. Swap in a few new photos every couple of months. That's simpler and needs no consent banner.

## Props
| Prop | Type | Default |
|---|---|---|
| `handle` | `string` | `'zumwohlmobil'` |
| `title` | `string` | `'Folge uns auf Instagram'` (du-voice) |
| `text` | `string` | `'Lass dich von unseren letzten Events inspirieren …'` |
| `posts` | `{ src, alt, href? }[]` | `[]` shows an empty state |

4 posts → 2/4 columns. 6 posts → 2/3/6 columns.
