import { InstagramSection } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const posts = [
{ src: "/e56c2db3-e63a-4410-b937-6b6aa697ab9e.jpg", alt: 'Zwei Gläser Aperol Spritz beim Anstoßen' },
{ src: "/7189ca72-4815-42b7-b022-ec721653a3fd.jpg", alt: 'Getränkespender mit Aperol Spritz und Eukalyptus' },
{ src: "/7dbf4d5a-2289-4ed9-9df7-23d44f5f8b97.jpg", alt: 'Gäste mit Spritz im Garten' },
{ src: "/38bcec88-2a26-48a1-9b7c-3fd8f26afa77.jpg", alt: 'Frische Zutaten für Spritz-Kreationen' }];


const previews: ComponentPreviewModule = {
  componentName: 'InstagramSection',
  importPath: 'components/InstagramSection',
  previews: [
  {
    name: '4 posts',
    description: 'Curated static grid linking to the profile',
    render: () => <InstagramSection posts={posts} />
  },
  {
    name: 'Empty',
    description: 'No images yet',
    render: () => <InstagramSection />
  }]

};

export default previews;