# NavLink

Uppercase, letter-spaced Jost navigation link. The active item shows a small dot marker before the label and a full 1px underline; inactive items reveal the underline on hover. Sets `aria-current="page"` when active.

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `active` | `boolean` | `false` | Current page — shows dot + underline |
| `size` | `'sm' \| 'md'` | `'md'` | Text size / tracking |
| `tone` | `'dark' \| 'light'` | `'dark'` | `dark` for light backgrounds, `light` for dark/image backgrounds |
| `hideDot` | `boolean` | `false` | Hide the active dot marker |
| `href` | `string` | `'#'` | Link target |
| ...rest | `AnchorHTMLAttributes` | — | Passed to the `<a>` (ref forwarded) |

Underline and dot use `currentColor`, so they follow the text color.

## Usage

```tsx
import { NavLink } from 'components/NavLink'

<nav aria-label="Hauptnavigation">
  <ul className="flex gap-8">
    <li><NavLink href="/">Home</NavLink></li>
    <li><NavLink href="/weine" active>Weine</NavLink></li>
    <li><NavLink href="/kontakt">Kontakt</NavLink></li>
  </ul>
</nav>

<NavLink href="/" tone="light">Home</NavLink>
```

Note: the Jost font is referenced by name; ensure it's loaded in `index.css` (Google Fonts) for it to render.
