import { NavLink } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const items = ['Home', 'Weine', 'Events', 'Über uns', 'Kontakt'];

const previews: ComponentPreviewModule = {
  componentName: 'NavLink',
  importPath: 'components/NavLink',
  previews: [
  {
    name: 'Default',
    description: 'Inactive link — underline grows on hover.',
    render: () => <NavLink href="#">Weine</NavLink>
  },
  {
    name: 'Active',
    description: 'Active item with dot marker and underline.',
    render: () =>
    <NavLink href="#" active>
          Weine
        </NavLink>

  },
  {
    name: 'Navigation bar',
    description: 'A row of links with one active item.',
    render: () =>
    <nav aria-label="Hauptnavigation">
          <ul className="flex flex-wrap items-center gap-8">
            {items.map((item) =>
        <li key={item}>
                <NavLink href="#" active={item === 'Events'}>
                  {item}
                </NavLink>
              </li>
        )}
          </ul>
        </nav>

  },
  {
    name: 'Light tone',
    description: 'For dark or image backgrounds.',
    render: () =>
    <div className="w-full bg-stone-900 px-8 py-6">
          <ul className="flex flex-wrap items-center gap-8">
            {items.map((item) =>
        <li key={item}>
                <NavLink href="#" tone="light" active={item === 'Home'}>
                  {item}
                </NavLink>
              </li>
        )}
          </ul>
        </div>

  },
  {
    name: 'Small',
    description: 'Compact size for footers or secondary menus.',
    render: () =>
    <ul className="flex items-center gap-6">
          <li>
            <NavLink href="#" size="sm" active>
              Impressum
            </NavLink>
          </li>
          <li>
            <NavLink href="#" size="sm">
              Datenschutz
            </NavLink>
          </li>
        </ul>

  }]

};

export default previews;