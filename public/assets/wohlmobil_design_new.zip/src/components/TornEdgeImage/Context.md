# TornEdgeImage

An image clipped with a soft, deterministic torn-paper edge. Used for botanical/collage photo moments. An optional cream paper fringe sits behind the photo for a real torn-paper look. Includes loading and error states.

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `src` | `string` | — | Image URL |
| `alt` | `string` | — | Alt text (`""` if decorative) |
| `edges` | `'all' \| 'top' \| 'bottom' \| 'top-bottom' \| 'left-right'` | `'all'` | Which edges are torn |
| `roughness` | `'soft' \| 'medium' \| 'rough'` | `'medium'` | Depth of the tear |
| `seed` | `number` | `7` | Changes the tear pattern (stable across renders) |
| `paper` | `boolean` | `true` | Cream paper fringe behind the tear |
| `aspectRatio` | `string` | `'4 / 3'` | CSS aspect ratio |
| `rotate` | `number` | `0` | Tilt in degrees for collages |
| `shadow` | `boolean` | `true` | Soft drop shadow following the torn shape |
| `caption` | `ReactNode` | — | Italic caption below |
| `className` | `string` | — | Extra classes on the `<figure>` |

Width follows the parent; height comes from `aspectRatio`.

## Usage

```tsx
import { TornEdgeImage } from 'components/TornEdgeImage'

<TornEdgeImage src={url} alt="Wildflowers" />

<TornEdgeImage src={url} alt="Vineyard" edges="top-bottom" roughness="rough" aspectRatio="21 / 9" />

<div className="w-60">
  <TornEdgeImage src={url} alt="Herbs" rotate={-3} seed={3} caption="Aus dem Garten" />
</div>
```

Use different `seed` values when several appear side by side so the tears don't repeat.
