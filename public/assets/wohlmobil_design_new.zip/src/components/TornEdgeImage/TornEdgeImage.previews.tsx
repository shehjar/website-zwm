import { TornEdgeImage } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const BOTANICAL = "/e0be34ec-5bd1-46b2-9bce-fa7b9cc9e480.jpg";

const VINEYARD = "/cc70ce52-f602-4f4f-ab06-bb631a0363b1.jpg";


const previews: ComponentPreviewModule = {
  componentName: 'TornEdgeImage',
  importPath: 'components/TornEdgeImage',
  previews: [
  {
    name: 'Default',
    description: 'All edges torn with a cream paper fringe',
    render: () =>
    <div className="w-full max-w-md bg-stone-100 p-8">
          <TornEdgeImage src={BOTANICAL} alt="Wildflower bouquet in a terracotta vase" />
        </div>

  },
  {
    name: 'Top & bottom tear',
    description: 'Banner-style tear for section transitions',
    render: () =>
    <div className="w-full max-w-2xl bg-stone-100 p-8">
          <TornEdgeImage
        src={VINEYARD}
        alt="Vineyard rows at golden hour"
        edges="top-bottom"
        roughness="rough"
        aspectRatio="21 / 9" />
      
        </div>

  },
  {
    name: 'Collage',
    description: 'Rotated pieces with captions and varied seeds',
    render: () =>
    <div className="flex w-full max-w-3xl flex-col items-center gap-8 bg-stone-100 p-10 sm:flex-row">
          <div className="w-64">
            <TornEdgeImage
          src={BOTANICAL}
          alt="Herb bouquet"
          rotate={-3}
          roughness="soft"
          seed={3}
          caption="Kräuter aus dem Garten" />
        
          </div>
          <div className="w-56">
            <TornEdgeImage
          src={VINEYARD}
          alt="Grape leaves"
          aspectRatio="3 / 4"
          rotate={4}
          seed={42}
          caption="Weinberg, Spätsommer" />
        
          </div>
        </div>

  },
  {
    name: 'No paper / error',
    description: 'Bare torn mask, and the fallback for a broken image',
    render: () =>
    <div className="grid w-full max-w-2xl grid-cols-2 gap-6 bg-stone-100 p-8">
          <TornEdgeImage src={BOTANICAL} alt="Bouquet" paper={false} shadow={false} />
          <TornEdgeImage src="https://invalid.example/missing.jpg" alt="Missing photo" />
        </div>

  }]

};

export default previews;