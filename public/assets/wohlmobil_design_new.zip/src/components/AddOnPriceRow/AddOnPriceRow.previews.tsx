import { WineIcon, MusicIcon, UsersIcon } from 'lucide-react';
import { AddOnPriceRow } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'AddOnPriceRow',
  importPath: 'components/AddOnPriceRow',
  previews: [
  {
    name: 'Default',
    description: 'Simple name and price',
    render: () =>
    <div className="w-full max-w-md">
          <AddOnPriceRow name="Extra Gläser (50 Stk.)" price={25} divider={false} />
        </div>

  },
  {
    name: 'Add-on panel list',
    description: 'Multiple rows with icons, descriptions and units',
    render: () =>
    <div className="w-full max-w-md rounded-xl border border-neutral-200 bg-white px-4">
          <AddOnPriceRow
        icon={<WineIcon className="h-4 w-4" />}
        name="Sektempfang"
        description="Inkl. Gläser & Service"
        price={4.5}
        unit="/ Gast" />
      
          <AddOnPriceRow
        icon={<UsersIcon className="h-4 w-4" />}
        name="Zusätzlicher Barkeeper"
        price={35}
        unit="/ Std." />
      
          <AddOnPriceRow
        icon={<MusicIcon className="h-4 w-4" />}
        name="Musikanlage"
        price="auf Anfrage" />
      
        </div>

  },
  {
    name: 'Highlighted total',
    description: 'Emphasized row, e.g. for a subtotal',
    render: () =>
    <div className="w-full max-w-md rounded-xl border border-neutral-200 bg-white px-4">
          <AddOnPriceRow name="Eiswürfel (10 kg)" price={12} />
          <AddOnPriceRow name="Summe Extras" price={37} highlighted />
        </div>

  }]

};

export default previews;