# AddOnPriceRow

Single line item that pairs an add-on name with its price. Used inside the add-on panel to list optional extras (e.g. Sektempfang, extra Barkeeper).

## Props
| Prop | Type | Default | Description |
|---|---|---|---|
| `name` | `ReactNode` | — | Add-on name (required) |
| `price` | `number \| string` | — | Numbers formatted as EUR (de-DE, e.g. `4,50 €`); strings render as-is (e.g. "auf Anfrage") |
| `description` | `ReactNode` | — | Secondary line under the name |
| `unit` | `string` | — | Suffix after price, e.g. `/ Gast` |
| `icon` | `ReactNode` | — | Leading icon in a round neutral badge |
| `highlighted` | `boolean` | `false` | Bold styling for totals/selected items |
| `divider` | `boolean` | `true` | Bottom border (auto-removed on last row) |
| `className` | `string` | — | Merged via tailwind-merge |

Also exports `formatPrice(price)`.

## Usage
```tsx
import { WineIcon } from 'lucide-react'
import { AddOnPriceRow } from 'components/AddOnPriceRow'

<div className="rounded-xl border border-neutral-200 bg-white px-4">
  <AddOnPriceRow icon={<WineIcon className="h-4 w-4" />} name="Sektempfang" price={4.5} unit="/ Gast" />
  <AddOnPriceRow name="Summe Extras" price={37} highlighted />
</div>
```
