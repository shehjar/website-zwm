import { PillTextarea } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'PillTextarea',
  importPath: 'components/PillTextarea',
  previews: [
  {
    name: 'Default',
    description: 'Message field with label and placeholder',
    render: () =>
    <div className="w-full max-w-md">
          <PillTextarea
        label="Ihre Nachricht"
        placeholder="Erzählen Sie uns von Ihrer Veranstaltung…" />
      
        </div>

  },
  {
    name: 'With counter',
    description: 'Helper text and live character count',
    render: () =>
    <div className="w-full max-w-md">
          <PillTextarea
        label="Anfrage"
        required
        maxLength={500}
        showCount
        helperText="Datum, Ort und Gästeanzahl helfen uns weiter."
        defaultValue="Hallo, wir planen eine Hochzeit am 12. Juni." />
      
        </div>

  },
  {
    name: 'Error',
    description: 'Validation error state',
    render: () =>
    <div className="w-full max-w-md">
          <PillTextarea
        label="Ihre Nachricht"
        required
        error="Bitte geben Sie eine Nachricht ein." />
      
        </div>

  },
  {
    name: 'Sizes & disabled',
    description: 'Small, large and disabled variants',
    render: () =>
    <div className="flex w-full max-w-md flex-col gap-4">
          <PillTextarea size="sm" placeholder="Klein" rows={2} />
          <PillTextarea size="lg" placeholder="Groß" />
          <PillTextarea disabled placeholder="Deaktiviert" />
        </div>

  }]

};

export default previews;