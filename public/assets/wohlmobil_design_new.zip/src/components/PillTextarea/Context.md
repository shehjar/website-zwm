# PillTextarea

Rounded, pill-style multi-line textarea for longer message fields (contact/booking forms). Matches PillInput styling: white surface, soft stone border, large radius, focus ring.

## Props
- `label?: string` – label above the field (shows `*` when `required`)
- `helperText?: string` – hint below the field
- `error?: string` – error message; sets red border and `aria-invalid`
- `size?: 'sm' | 'md' | 'lg'` – default `md`
- `showCount?: boolean` – live counter; requires `maxLength`
- `fullWidth?: boolean` – default `true`
- `wrapperClassName?: string` – classes for the outer wrapper
- All native `<textarea>` props (`rows`, `value`, `onChange`, `disabled`, …). Forwards ref.

## Usage
```tsx
import { PillTextarea } from 'components/PillTextarea'

<PillTextarea
  label="Ihre Nachricht"
  placeholder="Erzählen Sie uns von Ihrer Veranstaltung…"
  maxLength={500}
  showCount
  required
/>
```
