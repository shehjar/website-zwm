import React from 'react';
import { MobileMenuOverlay } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'MobileMenuOverlay',
  importPath: 'components/MobileMenuOverlay',
  previews: [
  {
    name: 'Trigger',
    description: 'Closed state – the menu icon button as it appears in the mobile header.',
    render: () =>
    <div className="flex w-full items-center justify-between bg-[#F4F6F1] px-6 py-4">
          <span className="font-['Jost',sans-serif] text-base font-medium uppercase tracking-[0.18em] text-[#2F3B33]">
            Zum Wohl Mobil
          </span>
          <MobileMenuOverlay hideOnDesktop={false} activeHref="/" />
        </div>

  },
  {
    name: 'Open – Start active',
    description: 'Full-screen overlay with START marked as the current page.',
    render: () =>
    <div className="min-h-[560px] w-full">
          <MobileMenuOverlay hideOnDesktop={false} defaultOpen activeHref="/" />
        </div>

  },
  {
    name: 'Open – Rezepte active',
    description: 'Active marker moves to the current page (REZEPTE).',
    render: () =>
    <div className="min-h-[560px] w-full">
          <MobileMenuOverlay hideOnDesktop={false} defaultOpen activeHref="/rezepte" />
        </div>

  }]

};

export default previews;