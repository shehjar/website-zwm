# MobileMenuOverlay

Menu icon button that opens a full-screen, calm pale-sage navigation overlay for mobile/tablet. Shows the logo, large uppercase Jost nav links with an active marker (sage line), and a close (X) button. Hidden at `lg` and above by default. The link list is centered vertically but scrolls safely when the screen is short, so the first link (START) is never clipped.

## Accessibility
- Trigger: `aria-haspopup="dialog"`, `aria-expanded`, German labels ("Menü öffnen" / "Menü schließen").
- Overlay: `role="dialog"`, `aria-modal`, focus moves to the close button, Tab/Shift+Tab are trapped, Escape closes, focus returns to the trigger. Body scroll is locked while open.
- Active link gets `aria-current="page"`.

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| `links` | `{ label, href }[]` | Start, Preise, Rezepte, Mietablauf, Über uns, Kontakt | Labels are rendered uppercase |
| `activeHref` | `string` | – | Matches a link `href` to show the active marker |
| `logo` | `ReactNode` | "ZUM WOHL MOBIL" wordmark | Pass the `Logo` component here |
| `onNavigate` | `(link, event) => void` | – | Menu closes automatically after click |
| `open` / `defaultOpen` / `onOpenChange` | | uncontrolled, `false` | Controlled or uncontrolled |
| `hideOnDesktop` | `boolean` | `true` | Adds `lg:hidden` |
| `className` | `string` | – | Wrapper classes |

## Usage
```tsx
import { MobileMenuOverlay } from 'components/MobileMenuOverlay'

<header className="flex items-center justify-between px-6 py-4">
  <Logo />
  <MobileMenuOverlay activeHref="/preise" logo={<Logo />} />
</header>
```
