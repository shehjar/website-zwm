import { SectionHeading } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'SectionHeading',
  importPath: 'components/SectionHeading',
  previews: [
  {
    name: 'Default',
    description: 'Centered script + Jost pairing',
    render: () =>
    <SectionHeading script="Willkommen" title="Zum Wohl Mobil" />

  },
  {
    name: 'With description & divider',
    description: 'Large size with supporting copy',
    render: () =>
    <SectionHeading
      script="Unser Angebot"
      title="Mobile Bar für jeden Anlass"
      description="Ob Hochzeit, Firmenfeier oder Geburtstag – wir bringen ausgewählte Weine und Drinks direkt zu Ihrem Event."
      size="lg"
      divider />


  },
  {
    name: 'Left aligned',
    description: 'Left alignment, small size',
    render: () =>
    <SectionHeading
      script="Kontakt"
      title="Schreiben Sie uns"
      align="left"
      size="sm"
      divider />


  },
  {
    name: 'Inverse',
    description: 'On a dark background',
    render: () =>
    <div className="w-full bg-stone-900 px-6 py-12">
          <SectionHeading
        script="Galerie"
        title="Eindrücke"
        description="Ein Blick hinter die Theke."
        tone="inverse" />
      
        </div>

  }]

};

export default previews;