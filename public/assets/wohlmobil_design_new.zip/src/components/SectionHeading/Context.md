# SectionHeading

Introduces a page section with a decorative script line (Allura) above an uppercase, letter-spaced Jost title. Optional divider and supporting description.

Fonts resolve via `--font-script` / `--font-body` CSS variables, falling back to `'Allura'` and `'Jost'` — make sure both are loaded (Google Fonts) in the consuming app.

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| `title` | `ReactNode` | — | Required. Main heading text (Jost, uppercase) |
| `script` | `ReactNode` | — | Script line above the title (Allura). Decorative visually; included for screen readers inside the heading |
| `description` | `ReactNode` | — | Supporting paragraph |
| `align` | `'left' \| 'center' \| 'right'` | `'center'` | |
| `size` | `'sm' \| 'md' \| 'lg'` | `'md'` | Scales both script and title |
| `tone` | `'default' \| 'inverse'` | `'default'` | Use `inverse` on dark/photo backgrounds |
| `as` | `'h1' \| 'h2' \| 'h3' \| 'h4'` | `'h2'` | Semantic heading level |
| `divider` | `boolean` | `false` | Short rule below the title |
| `className`, `id` | `string` | — | |

## Usage
```tsx
import { SectionHeading } from 'components/SectionHeading'

<SectionHeading script="Willkommen" title="Zum Wohl Mobil" />

<SectionHeading
  script="Unser Angebot"
  title="Mobile Bar für jeden Anlass"
  description="Wir bringen ausgewählte Weine direkt zu Ihrem Event."
  size="lg"
  divider
/>

<SectionHeading script="Galerie" title="Eindrücke" tone="inverse" />
```
