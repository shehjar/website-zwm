import React from 'react';
import { WatercolorBlot } from '../WatercolorBlot';

export type ScriptBannerVariant = 'band' | 'wash' | 'plain';

export interface ScriptBannerProps {
  /** Emotional one-liner in Allura, e.g. "Aperol Spritz – unsere Spezialität" */
  text: string;
  /** Optional small uppercase Jost line above the script text */
  eyebrow?: string;
  /** Append a small heart after the text */
  heart?: boolean;
  /** `band` = pale sage strip, `wash` = watercolor blot behind, `plain` = no background */
  variant?: ScriptBannerVariant;
  /** Render the script text as a heading (for screen readers) */
  as?: 'p' | 'h2' | 'h3';
  className?: string;
}

export function ScriptBanner({
  text,
  eyebrow,
  heart = false,
  variant = 'band',
  as: Tag = 'p',
  className = ''
}: ScriptBannerProps) {
  return (
    <section
      className={`relative isolate w-full overflow-hidden px-5 text-center ${
      variant === 'band' ? 'bg-card py-12 md:py-16' : 'py-14 md:py-20'} ${
      className}`}>
      
      {variant === 'wash' &&
      <WatercolorBlot variant="splash" position="center" size={560} opacity={0.9} className="max-w-[140%]" />
      }
      {eyebrow &&
      <p className="mb-3 text-xs font-medium uppercase tracking-[0.25em] text-text">{eyebrow}</p>
      }
      <Tag
        className="mx-auto max-w-4xl text-5xl leading-tight text-text md:text-6xl"
        style={{ fontFamily: 'Allura, cursive', fontWeight: 400 }}>
        
        {text}
        {heart &&
        <span aria-hidden="true" className="ml-3 inline-block align-middle text-3xl text-accent">
            ♡
          </span>
        }
      </Tag>
    </section>);

}