import { ScriptBanner } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'ScriptBanner',
  importPath: 'components/ScriptBanner',
  previews: [
  {
    name: 'Specialty band',
    description: 'Homepage highlight on a pale sage strip',
    render: () => <ScriptBanner text="Aperol Spritz – unsere Spezialität" />
  },
  {
    name: 'Watercolor wash',
    description: 'Rezepte footer callout with heart',
    render: () =>
    <div className="w-full bg-background">
          <ScriptBanner variant="wash" text="Wähle das Getränk, das dir am besten schmeckt!" heart />
        </div>

  },
  {
    name: 'With eyebrow',
    description: 'Plain variant with small uppercase intro',
    render: () =>
    <div className="w-full bg-background">
          <ScriptBanner variant="plain" eyebrow="Unsere Spezialität" text="Aperol Spritz" as="h2" />
        </div>

  }]

};

export default previews;