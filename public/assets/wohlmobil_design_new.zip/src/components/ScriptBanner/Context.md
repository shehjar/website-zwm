# ScriptBanner

A full-width strip with one emotional line in Allura script. Use it for short moments with personality, at most once or twice per page.

- Homepage: "Aperol Spritz – unsere Spezialität" (`variant="band"`)
- Rezepte page footer: "Wähle das Getränk, das dir am besten schmeckt!" with `heart` (`variant="wash"`)

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| `text` | `string` | — | Keep it short (one line on desktop) |
| `eyebrow` | `string` | — | Small uppercase Jost line above |
| `heart` | `boolean` | `false` | Adds a small Aperol-orange ♡ (decorative) |
| `variant` | `'band' \| 'wash' \| 'plain'` | `'band'` | `band` = pale sage strip, `wash` = watercolor blot behind |
| `as` | `'p' \| 'h2' \| 'h3'` | `'p'` | Use `h2` when the line acts as a section title |
| `className` | `string` | — | |
