import { InquiryForm } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

/** Previews never send real emails — they simulate delivery. */
const simulate = async () => {
  await new Promise((r) => setTimeout(r, 800));
};

const previews: ComponentPreviewModule = {
  componentName: 'InquiryForm',
  importPath: 'components/InquiryForm',
  previews: [
  {
    name: 'Canva style (rounded)',
    description: 'Rounded fields, full-width button. Submit empty to see validation. (Preview simulates sending.)',
    render: () =>
    <div className="w-full max-w-3xl bg-background p-6 md:p-10">
          <InquiryForm title="Anfrageformular" initialEventType="hochzeit" onSubmit={simulate} />
        </div>

  },
  {
    name: 'Pre-filled tier',
    description: 'Opened from a PricingTierCard ("bis 60 Gäste")',
    render: () =>
    <div className="w-full max-w-3xl bg-background p-6 md:p-10">
          <InquiryForm initialGuests={60} onSubmit={simulate} />
        </div>

  },
  {
    name: 'Send error',
    description: 'Submission fails — fill the form and send to see the error banner',
    render: () =>
    <div className="w-full max-w-3xl bg-background p-6 md:p-10">
          <InquiryForm
        initialGuests={30}
        onSubmit={async () => {
          await new Promise((r) => setTimeout(r, 600));
          throw new Error('Network');
        }} />
      
        </div>

  }]

};

export default previews;