# InquiryForm

The complete Anfrageformular, composed from PillInput, PillDateInput, PillSelect, PillTextarea, ConsentCheckbox, PillButton and FormStatusMessage. Use this instead of hand-assembling the fields.

## Fields (in order)
Name*, Telefonnummer*, E-Mail-Adresse* · Wunschtermin* (date, no past dates), Art der Veranstaltung* (dropdown), Ort der Veranstaltung*, Personenanzahl* (number) · message (optional, 1000 chars) · DSGVO consent*.

Desktop pairs related fields in two columns; mobile stacks them.

## Behaviour
- Inline German "du" validation on submit; focus jumps to the first invalid field.
- Sending state disables all fields and shows a spinner on the button.
- Error → dismissible FormStatusMessage. Success → replaces the form with a warm thank-you card that says it's **unverbindlich** and **noch keine Buchung**.
- The non-binding note always sits under the submit button.

## Delivery
Inquiries go to `INQUIRY_RECIPIENT = 'zumwohlmobil@gmail.com'` via FormSubmit (`sendViaFormSubmit`, no backend needed). The email has a readable subject ("Neue Anfrage: Hochzeit am 12.06.2027"), and *Reply* goes straight to the customer.

**One-time activation:** the very first submission sends an activation email to zumwohlmobil@gmail.com. Click "Activate Form" in that email; from then on every inquiry arrives. Name FormSubmit as a processor in the Datenschutzerklärung. Pass a custom `onSubmit` to use another service.

## Props
| Prop | Type | Default |
|---|---|---|
| `title` | `string` | `'Anfrageformular'` |
| `intro` | `string` | warm du-intro |
| `initialGuests` | `number \| null` | — (from PricingTierCard; `null` = individual offer) |
| `initialEventType` | `string` | `''` |
| `shape` | `'rounded' \| 'pill'` | `'rounded'` (Canva look) |
| `privacyHref` | `string` | `'/datenschutz'` |
| `onSubmit` | `(values, recipient) => Promise<void>` | `sendViaFormSubmit` |
| `className` | `string` | — |

## Usage
```tsx
const [guests, setGuests] = useState<number | null>()

<PricingTierCard guests={60} price="400,00 €" href="#anfrage" onSelect={(t) => setGuests(t.guests)} />

<div id="anfrage">
  <InquiryForm key={String(guests)} initialGuests={guests} title="Anfrageformular Heiraterei & Feierei Special" />
</div>
```
Use `key` so the form re-initialises when a different tier is clicked.
