# InfoTextBlock

A titled text section. It has an uppercase Jost heading, an optional intro, an optional list of items (each with an icon and a short bold lead-in) and free-form paragraphs.

Use it for:
- **Preise**: "Was ist in der Getränkepauschale enthalten?" with 3 icon items (GlassWater, HandPlatter, Truck).
- **Über uns**: story paragraphs, passed as `children` with `variant="plain"`.

## Props
| Prop | Type | Default |
|---|---|---|
| `title` | `string` | — |
| `intro` | `ReactNode` | — |
| `items` | `{ icon?, title?, text }[]` | — |
| `children` | `ReactNode` | — |
| `variant` | `'card' \| 'plain'` | `'card'` (pale sage, 32px radius) |
| `as` | `'h2' \| 'h3'` | `'h2'` |

Tip: break long paragraphs into items with a bold lead-in. Visitors scan prices pages and don't read them word for word.
