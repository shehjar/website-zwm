import { GlassWaterIcon, HandPlatterIcon, TruckIcon } from 'lucide-react';
import { InfoTextBlock } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'InfoTextBlock',
  importPath: 'components/InfoTextBlock',
  previews: [
  {
    name: 'Inklusivleistungen',
    description: 'What the flat rate includes (Preise page)',
    render: () =>
    <div className="w-full max-w-4xl bg-background p-6">
          <InfoTextBlock
        title="Was ist in der Getränkepauschale enthalten?"
        items={[
        {
          icon: <GlassWaterIcon strokeWidth={1.5} />,
          title: 'Ein Getränk pro Person',
          text:
          <>
                    Wir bieten ausschließlich Aperol Spritz und verschiedene Aperol-Kreationen an. Eine Übersicht
                    findest du unter{' '}
                    <a href="/rezepte" className="underline underline-offset-2 hover:text-accent">
                      Rezepte
                    </a>
                    .
                  </>

        },
        {
          icon: <HandPlatterIcon strokeWidth={1.5} />,
          title: 'Selbstbedienungsbar',
          text: 'Aufbau, Vorbereitung und Abbau sind bereits Bestandteil der Buchung. Ein Ausschank oder eine Betreuung der Gäste vor Ort ist nicht vorgesehen.'
        },
        {
          icon: <TruckIcon strokeWidth={1.5} />,
          title: 'Anfahrt inklusive bis 50 km',
          text: 'Für jeden weiteren Kilometer berechnen wir 3,00 €.'
        }]
        } />
      
        </div>

  },
  {
    name: 'Story (plain)',
    description: 'Über uns story paragraphs',
    render: () =>
    <div className="w-full max-w-3xl bg-background p-6">
          <InfoTextBlock variant="plain" title="Unsere Geschichte">
            <p>
              Willkommen bei Zum Wohl Mobil! Wir glauben, dass die schönsten Erinnerungen dort entstehen, wo Menschen
              zusammenkommen, anstoßen und gemeinsam das Leben feiern.
            </p>
            <p>
              Unsere mobile Bar haben wir mit viel Liebe zum Detail gestaltet, um jedem Event eine ganz besondere,
              stilvolle Note zu verleihen.
            </p>
          </InfoTextBlock>
        </div>

  }]

};

export default previews;