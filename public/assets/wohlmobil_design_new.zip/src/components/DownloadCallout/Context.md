# DownloadCallout

A thin-bordered rounded box with a file icon, a short text and the "Herunterladen" pill button. Use it on the Preise page for the price list.

By default it links to the current Preisliste (`PRICE_LIST_URL`, an A4 image). When the real PDF is exported from Canva, replace `PRICE_LIST_URL` or pass `href` + `fileName`. If `href` is empty, the button is disabled and the box shows "Bald verfügbar".

## Props
| Prop | Type | Default |
|---|---|---|
| `text` | `string` | `'Unsere Preisliste herunterladen'` (switch back to "…als PDF…" once the file is a real PDF) |
| `buttonLabel` | `string` | `'Herunterladen'` |
| `href` | `string` | `PRICE_LIST_URL` |
| `fileName` | `string` | `'Zum-Wohl-Mobil-Preisliste.png'` |
| `meta` | `string` | `'Preisliste · A4'` |

Keep the price list in sync with the website prices (250 / 400 / 550 €, Wagenmiete 120 €, Dekoration 30 €, 3,00 € per km beyond 50 km).
