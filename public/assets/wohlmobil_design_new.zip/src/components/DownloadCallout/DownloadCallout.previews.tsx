import { DownloadCallout } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'DownloadCallout',
  importPath: 'components/DownloadCallout',
  previews: [
  {
    name: 'Price list',
    description: 'Default — links to the current Preisliste',
    render: () =>
    <div className="w-full max-w-3xl bg-background p-6">
          <DownloadCallout />
        </div>

  },
  {
    name: 'File missing',
    description: 'Empty href — button disabled, "Bald verfügbar"',
    render: () =>
    <div className="w-full max-w-3xl bg-background p-6">
          <DownloadCallout href="" />
        </div>

  }]

};

export default previews;