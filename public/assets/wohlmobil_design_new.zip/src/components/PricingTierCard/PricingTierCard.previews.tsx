import React, { useState } from 'react';
import { PricingTierCard } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

function TierGrid() {
  const [selected, setSelected] = useState<number | null | undefined>(undefined);
  const tiers = [
  { guests: 30, price: 'ab 690 €' },
  { guests: 60, price: 'ab 1.190 €' },
  { guests: 100, price: 'ab 1.790 €' }];

  return (
    <div className="w-full max-w-5xl">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {tiers.map((t) =>
        <PricingTierCard
          key={t.guests}
          guests={t.guests}
          price={t.price}
          selected={selected === t.guests}
          onSelect={(tier) => setSelected(tier.guests)} />

        )}
        <PricingTierCard custom selected={selected === null} onSelect={() => setSelected(null)} />
      </div>
      <p className="mt-6 text-center text-sm text-stone-500">
        Vorausgewählt im Formular:{' '}
        <strong className="text-stone-900">
          {selected === undefined ? '–' : selected === null ? 'Individuelles Angebot' : `Bis ${selected} Gäste`}
        </strong>
      </p>
    </div>);

}

const previews: ComponentPreviewModule = {
  componentName: 'PricingTierCard',
  importPath: 'components/PricingTierCard',
  previews: [
  {
    name: 'Default',
    description: 'Standard guest tier with price',
    render: () =>
    <div className="w-64">
          <PricingTierCard guests={30} price="ab 690 €" />
        </div>

  },
  {
    name: 'Selected',
    description: 'Currently selected tier',
    render: () =>
    <div className="w-64">
          <PricingTierCard guests={60} price="ab 1.190 €" selected />
        </div>

  },
  {
    name: 'Custom Offer',
    description: 'Fourth tier linking to a custom inquiry',
    render: () =>
    <div className="w-64">
          <PricingTierCard custom href="#anfrage" />
        </div>

  },
  {
    name: 'Tier Grid',
    description: 'Four tiers with selection passed to the request form',
    render: () => <TierGrid />
  }]

};

export default previews;