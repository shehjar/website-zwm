# PricingTierCard

Clickable pricing card for the Zum Wohl Mobil packages: people icon, uppercase guest label ("BIS 30 GÄSTE"), short divider and price. Clicking calls `onSelect` with the tier so the request form can be pre-filled. The custom variant reads "INDIVIDUELLES ANGEBOT" and links to a custom inquiry.

Renders a `<button>` by default, or an `<a>` when `href` is set (`onSelect` still fires).

## Props
| Prop | Type | Default | Description |
|---|---|---|---|
| `guests` | `number \| null` | `null` | Max guest count. `null` → custom tier |
| `price` | `string` | – | e.g. `"ab 690 €"` |
| `custom` | `boolean` | auto | Force "Individuelles Angebot" variant |
| `label` | `string` | auto | Override label |
| `customHint` | `string` | `"Ab 91 Gästen – jetzt anfragen"` | Text shown instead of price on custom tier |
| `selected` | `boolean` | `false` | Selected styling (`aria-pressed`) |
| `onSelect` | `(tier: { guests: number \| null; price?: string }) => void` | – | Pre-fill callback |
| `href` | `string` | – | Render as link, e.g. `#anfrage` |
| `className` | `string` | – | Extra classes (merged) |

## Usage
```tsx
<div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
  <PricingTierCard guests={30} price="ab 690 €" href="#anfrage" onSelect={(t) => setGuests(t.guests)} />
  <PricingTierCard guests={60} price="ab 1.190 €" href="#anfrage" onSelect={(t) => setGuests(t.guests)} />
  <PricingTierCard guests={100} price="ab 1.790 €" href="#anfrage" onSelect={(t) => setGuests(t.guests)} />
  <PricingTierCard custom href="#anfrage" onSelect={() => setGuests(null)} />
</div>
```
