import React from 'react';
import { PillInput } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'PillInput',
  importPath: 'components/PillInput',
  previews: [
  {
    name: 'Default',
    description: 'Text input with label',
    render: () =>
    <div className="w-full max-w-sm">
          <PillInput label="Name" placeholder="Max Mustermann" />
        </div>

  },
  {
    name: 'Required',
    description: 'Required email input with hint',
    render: () =>
    <div className="w-full max-w-sm">
          <PillInput
        label="E-Mail"
        type="email"
        required
        placeholder="name@beispiel.de"
        hint="Wir melden uns innerhalb von 24 Stunden." />
      
        </div>

  },
  {
    name: 'Error',
    description: 'Inline error state',
    render: () =>
    <div className="w-full max-w-sm">
          <PillInput
        label="Telefon"
        type="tel"
        required
        defaultValue="0123"
        error="Bitte gib eine gültige Telefonnummer ein." />
      
        </div>

  },
  {
    name: 'Number & Disabled',
    description: 'Number input and disabled state',
    render: () =>
    <div className="flex w-full max-w-sm flex-col gap-4">
          <PillInput label="Anzahl Gäste" type="number" min={1} placeholder="50" />
          <PillInput label="Ort" placeholder="Nicht verfügbar" disabled />
        </div>

  }]

};

export default previews;