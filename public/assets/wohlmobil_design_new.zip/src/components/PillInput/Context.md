# PillInput

Pill-shaped (fully rounded) form input with a label above, optional required marker, helper text and inline error message. Supports `text`, `number`, `tel` and `email`.

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `label` | `string` | — | Visible label above the input (required) |
| `type` | `'text' \| 'number' \| 'tel' \| 'email'` | `'text'` | Input type |
| `required` | `boolean` | `false` | Adds `*` (plus "Pflichtfeld" for screen readers) and native `required` |
| `error` | `string` | — | Error message; turns border red, sets `aria-invalid` |
| `hint` | `string` | — | Helper text shown when there is no error |
| `shape` | `'pill' \| 'rounded'` | `'pill'` | `rounded` = 16px corners, matching the Canva inquiry form |

Styled with design tokens: `text-text` labels, `border-muted-text` border, `border-primary` on hover/focus, `bg-surface`.
| `className` | `string` | — | Classes for the outer wrapper |

All other native `<input>` props (`value`, `onChange`, `placeholder`, `name`, `disabled`, …) are forwarded. The ref is forwarded to the `<input>`.

## Usage

```tsx
import { PillInput } from 'components/PillInput'

<PillInput label="Name" placeholder="Max Mustermann" />
<PillInput label="E-Mail" type="email" required />
<PillInput label="Telefon" type="tel" error="Bitte gib eine gültige Nummer ein." />
```

## Notes
- Full width by default; constrain with a parent container.
- Number spinners are hidden for a clean pill look.
- Error text uses `role="alert"` and is linked via `aria-describedby`.
