import { BotanicalDecoration } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'BotanicalDecoration',
  importPath: 'components/BotanicalDecoration',
  previews: [
  {
    name: 'Variants',
    description: 'All six transparent watercolor illustrations',
    render: () =>
    <div className="grid grid-cols-2 items-center gap-8 bg-background p-6 md:grid-cols-3">
          <BotanicalDecoration variant="eucalyptus" size={180} />
          <BotanicalDecoration variant="branch" size={180} />
          <BotanicalDecoration variant="corner" size={170} />
          <BotanicalDecoration variant="sprig" size={150} />
          <BotanicalDecoration variant="twin" size={120} />
          <BotanicalDecoration variant="garland" size={180} />
        </div>

  },
  {
    name: 'Transparency',
    description: 'The same sprig at opacity 1, 0.6, 0.35 and 0.15',
    render: () =>
    <div className="flex flex-wrap items-center gap-6 bg-background p-6">
          {[1, 0.6, 0.35, 0.15].map((o) =>
      <div key={o} className="flex flex-col items-center gap-2">
              <BotanicalDecoration variant="sprig" size={130} opacity={o} />
              <span className="text-xs text-muted-text">{o}</span>
            </div>
      )}
        </div>

  },
  {
    name: 'Rotation',
    description: 'The same branch at 0°, 30°, 90°, 180° and -45°',
    render: () =>
    <div className="flex flex-wrap items-center gap-8 bg-background p-6">
          {[0, 30, 90, 180, -45].map((r) =>
      <div key={r} className="flex flex-col items-center gap-3">
              <div className="flex h-36 w-36 items-center justify-center">
                <BotanicalDecoration variant="eucalyptus" size={120} rotate={r} />
              </div>
              <span className="text-xs text-muted-text">rotate={r}</span>
            </div>
      )}
        </div>

  },
  {
    name: 'Flip',
    description: 'Corner sprig mirrored to fit all four corners',
    render: () =>
    <div className="grid grid-cols-2 gap-6 bg-background p-6">
          {[
      { label: 'none', flip: false, flipVertical: false },
      { label: 'flip', flip: true, flipVertical: false },
      { label: 'flipVertical', flip: false, flipVertical: true },
      { label: 'flip + flipVertical', flip: true, flipVertical: true }].
      map((c) =>
      <div key={c.label} className="flex flex-col items-center gap-2">
              <BotanicalDecoration variant="corner" size={140} flip={c.flip} flipVertical={c.flipVertical} />
              <span className="text-xs text-muted-text">{c.label}</span>
            </div>
      )}
        </div>

  },
  {
    name: 'Section accents',
    description: 'Rotated, flipped and faded behind content',
    render: () =>
    <section className="relative isolate w-full max-w-xl overflow-hidden rounded-[32px] bg-background px-10 py-20 text-center">
          <BotanicalDecoration variant="garland" position="top-left" size={240} opacity={0.5} />
          <BotanicalDecoration variant="sprig" position="bottom-right" size={180} rotate={160} opacity={0.3} />
          <h2 className="text-5xl text-text" style={{ fontFamily: 'Allura, cursive' }}>
            Zum Wohl Mobil
          </h2>
          <p className="mt-3 text-text">Deine mobile Bar für Hochzeiten, Geburtstage & Feste.</p>
        </section>

  }]

};

export default previews;