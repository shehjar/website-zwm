# BotanicalDecoration

Decorative watercolor eucalyptus illustrations on transparent backgrounds. These are real brand assets: never redraw or substitute them. Use them as accents around page sections. They are decorative only (`aria-hidden`, `pointer-events-none`). Corner positions sit behind the content (`-z-10`), so give the parent `relative isolate`.

## Variants
- `eucalyptus`: a pale, round-leaf branch on a diagonal
- `branch`: a slender, airy sprig sweeping diagonally
- `corner`: an L-shaped corner sprig that fits bottom-left. Flip or rotate it for other corners
- `sprig`: a short sprig with dark, saturated leaves. It's the strongest accent, so fade it behind text
- `twin`: a tall, upright double branch. Good on the side edges
- `garland`: a dense top-left corner garland. Use it in the hero or a header corner

Asset URLs are exported as `BOTANICAL_SOURCES`.

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| `variant` | see above | `'eucalyptus'` | Illustration |
| `position` | `'top-left' \| 'top-right' \| 'bottom-left' \| 'bottom-right' \| 'inline'` | `'inline'` | Corner positions are `absolute` |
| `size` | `number` | `220` | Width in px |
| `rotate` | `number` | `0` | Degrees, any value (positive = clockwise) |
| `flip` | `boolean` | `false` | Mirror horizontally (left ↔ right) |
| `flipVertical` | `boolean` | `false` | Mirror vertically (top ↔ bottom). Combine with `flip` to move `corner`/`garland` into any corner |
| `opacity` | `number` | `1` | Transparency from 0 to 1, clamped. Suggested: about 0.6 for accents beside content, 0.25–0.4 behind text, 0.15 for faint texture |
| `mobileScale` | `number` | `0.55` | Smallest scale on phones. The width shrinks smoothly from `size` (≥ ~1100px) to `size × mobileScale` (~375px). `1` = fixed size |
| `className` | `string` | — | e.g. `!-top-8 md:!-top-14` to nudge offsets per breakpoint |

Decorations should stay visible on mobile. Let `mobileScale` shrink them rather than hiding them with `hidden md:block`.

## Corner recipes (`corner` sprig, drawn for bottom-left)
- bottom-left: none · bottom-right: `flip` · top-left: `flipVertical` · top-right: `flip flipVertical`
- `garland` is drawn for top-left: top-right `flip` · bottom-left `flipVertical` · bottom-right both

Rotation is applied before mirroring. Small rotations (±10–25°) make repeated sprigs look less mechanical.

## Usage
```tsx
<section className="relative isolate overflow-hidden">
  <BotanicalDecoration variant="garland" position="top-left" opacity={0.5} />
  <BotanicalDecoration variant="sprig" position="bottom-right" rotate={160} opacity={0.3} />
  ...
</section>
```
