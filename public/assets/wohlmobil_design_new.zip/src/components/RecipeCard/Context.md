# RecipeCard

Drink card for the Rezepte page. It's a flat, pale sage card (32px radius, no shadow) with a photo, an optional character tag (white pill), an uppercase Jost title, a short sage divider and the ingredient list in **Bebas Neue**. Ingredient lists are the only place Bebas Neue is allowed.

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| `title` | `string` | — | Drink name |
| `subtitle` | `string` | — | Optional short description |
| `imageSrc` / `imageAlt` | `string` | — | Shows a glass icon when there's no image |
| `ingredients` | `{ name; amount? }[]` | — | Rendered uppercase in Bebas Neue |
| `tag` | `string` | — | e.g. Klassiker, Fruchtig, Alkoholfrei |
| `variant` | `'sage' \| 'white'` | `'sage'` | `white` = thin sage border, for use on sage sections |
| `loading` | `boolean` | `false` | Skeleton |
| `className` | `string` | — | |

## Rezepte content
| Drink | Ingredients | Tag |
|---|---|---|
| Aperol Spritz | Aperol, Prosecco, Soda, Orange | Klassiker |
| Tropical Spritz | Aperol, Prosecco, Soda, Mangonektar, Mango | Fruchtig |
| Wild Berry Spritz | Aperol, Prosecco, Wild Berry Soda, Beeren | Fruchtig & spritzig |
| Virgin Spritz | Crodino, Alkoholfreier Sekt, Soda, Orange | Alkoholfrei |

Grid: `grid gap-6 sm:grid-cols-2 lg:grid-cols-4`. Follow it with `<ScriptBanner variant="wash" heart text="Wähle das Getränk, das dir am besten schmeckt!" />`.
