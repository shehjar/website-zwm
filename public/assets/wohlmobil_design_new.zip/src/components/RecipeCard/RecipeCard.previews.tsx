import { RecipeCard } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const SPRITZ = "/8bdd0ccf-9e1b-4667-87c1-797871262e03.jpg";
const TROPICAL = "/e25642db-3186-4a6b-9ba3-b07ecd713548.jpg";
const BERRY = "/302f766c-0be4-4d01-b352-fc13ce20cf7e.jpg";
const VIRGIN = "/bb8298ce-321a-48d6-b36c-a204aa2ed714.jpg";

const ing = (...names: string[]) => names.map((name) => ({ name }));

const previews: ComponentPreviewModule = {
  componentName: 'RecipeCard',
  importPath: 'components/RecipeCard',
  previews: [
  {
    name: 'Default',
    description: 'Pale sage card: Jost title, Bebas Neue ingredients',
    render: () =>
    <RecipeCard
      title="Aperol Spritz"
      tag="Klassiker"
      imageSrc={SPRITZ}
      imageAlt="Aperol Spritz mit Orangenscheibe"
      ingredients={ing('Aperol', 'Prosecco', 'Soda', 'Orange')} />


  },
  {
    name: 'Rezepte grid',
    description: 'All four drinks as on the Rezepte page',
    render: () =>
    <div className="grid w-full gap-6 bg-background p-6 sm:grid-cols-2 lg:grid-cols-4">
          <RecipeCard title="Aperol Spritz" tag="Klassiker" imageSrc={SPRITZ} ingredients={ing('Aperol', 'Prosecco', 'Soda', 'Orange')} />
          <RecipeCard title="Tropical Spritz" tag="Fruchtig" imageSrc={TROPICAL} ingredients={ing('Aperol', 'Prosecco', 'Soda', 'Mangonektar', 'Mango')} />
          <RecipeCard title="Wild Berry Spritz" tag="Fruchtig & spritzig" imageSrc={BERRY} ingredients={ing('Aperol', 'Prosecco', 'Wild Berry Soda', 'Beeren')} />
          <RecipeCard title="Virgin Spritz" tag="Alkoholfrei" imageSrc={VIRGIN} ingredients={ing('Crodino', 'Alkoholfreier Sekt', 'Soda', 'Orange')} />
        </div>

  },
  {
    name: 'White & no image',
    description: 'White variant with thin sage border, image fallback',
    render: () =>
    <div className="bg-background p-6">
          <RecipeCard variant="white" title="Virgin Spritz" tag="Alkoholfrei" ingredients={ing('Crodino', 'Alkoholfreier Sekt', 'Soda', 'Orange')} />
        </div>

  },
  {
    name: 'Loading',
    description: 'Skeleton while data loads',
    render: () => <RecipeCard loading title="" ingredients={[]} />
  }]

};

export default previews;