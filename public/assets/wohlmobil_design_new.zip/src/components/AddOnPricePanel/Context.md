# AddOnPricePanel

Pale sage card that groups multiple add-on price rows under a shared heading. Used on pricing pages to list optional extras.

## Props
- `heading: string` – panel title (rendered as h3, labels the section)
- `description?: string` – short intro under the heading
- `items?: { id?, label, description?, price, unit? }[]` – built-in rows, divided by sage lines
- `children?: ReactNode` – custom rows (e.g. `AddOnPriceRow`) rendered in a divided list
- `footnote?: string` – small note at the bottom (e.g. "zzgl. MwSt.")
- `className?: string`

## Usage
```tsx
<AddOnPricePanel
  heading="Zusatzleistungen"
  items={[
    { label: 'Barkeeper', price: '45 €', unit: '/ Std.' },
    { label: 'Eiswürfel', price: '12 €' },
  ]}
  footnote="Alle Preise zzgl. MwSt."
/>
```
