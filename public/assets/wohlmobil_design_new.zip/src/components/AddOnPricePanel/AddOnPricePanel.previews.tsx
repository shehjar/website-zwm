import { AddOnPricePanel } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'AddOnPricePanel',
  importPath: 'components/AddOnPricePanel',
  previews: [
  {
    name: 'Default',
    description: 'Panel with several add-on rows',
    render: () =>
    <div style={{ maxWidth: 520, width: '100%' }}>
          <AddOnPricePanel
        heading="Zusatzleistungen"
        description="Optional zu jeder Buchung hinzufügbar."
        items={[
        { label: 'Barkeeper', description: 'Pro Person, inkl. Anfahrt', price: '45 €', unit: '/ Std.' },
        { label: 'Gläser-Service', price: '1,50 €', unit: '/ Glas' },
        { label: 'Eiswürfel', description: '10 kg Sack', price: '12 €' }]
        }
        footnote="Alle Preise zzgl. MwSt." />
      
        </div>

  },
  {
    name: 'Heading only rows',
    description: 'Minimal panel without description or footnote',
    render: () =>
    <div style={{ maxWidth: 520, width: '100%' }}>
          <AddOnPricePanel
        heading="Extras"
        items={[
        { label: 'Stehtische', price: '15 €', unit: '/ Stück' },
        { label: 'Lichterkette', price: '25 €' }]
        } />
      
        </div>

  },
  {
    name: 'Custom children',
    description: 'Pass custom rows (e.g. AddOnPriceRow) as children',
    render: () =>
    <div style={{ maxWidth: 520, width: '100%' }}>
          <AddOnPricePanel heading="Anfahrt">
            <div className="flex justify-between py-3 text-sm text-[#2f3d2c]">
              <span>Bis 30 km</span>
              <span className="font-semibold">inklusive</span>
            </div>
            <div className="flex justify-between py-3 text-sm text-[#2f3d2c]">
              <span>Jeder weitere km</span>
              <span className="font-semibold">0,80 €</span>
            </div>
          </AddOnPricePanel>
        </div>

  }]

};

export default previews;