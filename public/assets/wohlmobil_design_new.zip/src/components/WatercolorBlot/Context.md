# WatercolorBlot

Abstract liquid watercolor blob shapes in pale sage-grey (real brand SVG assets — never redraw, recolour or substitute). The companion to **BotanicalDecoration**: blobs are the soft "ground", sprigs sit on top. Decorative only (`aria-hidden`, `pointer-events-none`). Absolute positions sit behind content (negative z-index), so give the parent `relative isolate` (and usually `overflow-hidden`).

For whole-section backgrounds, **WatercolorBackground** arranges washes for you; use WatercolorBlot for one-off or custom placements.

## Variants
- `splash` — wide blob with layered pools and splatter dots. Hero / behind wide content.
- `wash` — very pale, square-ish wash. A quiet base layer under other blobs or text.
- `drift` — diagonal splash with droplets. Corners and section edges.

All variants are transparent SVGs. Only add new blot assets if they have a transparent background.

Asset URLs are exported as `WATERCOLOR_BLOT_SOURCES`.

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| `variant` | see above | `'splash'` | Blob shape |
| `position` | `'top-left' \| 'top-right' \| 'bottom-left' \| 'bottom-right' \| 'center' \| 'inline'` | `'inline'` | Non-inline values are `absolute` behind content |
| `size` | `number` | `360` | Width in px |
| `rotate` | `number` | `0` | Degrees |
| `flip` / `flipVertical` | `boolean` | `false` | Mirror — combine with rotate so one asset reads as many blobs |
| `opacity` | `number` | `1` | Transparency 0–1 (clamped). Lower behind dense text |
| `layer` | `number` | `0` | 0–9 stacking order for overlapping blobs; higher sits on top, all stay behind content |
| `blend` | `boolean` | `true` | Multiply blend so overlaps deepen like real pigment |
| `mobileScale` | `number` | `0.55` | Smallest scale on phones (width shrinks smoothly from `size` down to `size × mobileScale`). `1` = fixed size |
| `className` | `string` | — | e.g. `!top-4 !left-8` to nudge offsets |

## Stacking & mixing
```tsx
<section className="relative isolate overflow-hidden">
  <WatercolorBlot variant="wash" position="center" size={420} layer={0} />
  <WatercolorBlot variant="splash" position="center" size={300} layer={1} rotate={20} opacity={0.7} />
  <BotanicalDecoration variant="corner" position="top-left" size={160} />
  <h2>…</h2>
</section>
```

## Guidelines
- Use sparingly — 1–3 blobs per section, not every section.
- Keep visible on mobile. Blots shrink automatically via `mobileScale`, so don't hide them.
- Never place over text; content always sits above blobs.
