import { WatercolorBlot } from './index';
import { BotanicalDecoration } from '../BotanicalDecoration';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'WatercolorBlot',
  importPath: 'components/WatercolorBlot',
  previews: [
  {
    name: 'Variants',
    description: 'The liquid watercolor blob shapes',
    render: () =>
    <div className="flex flex-wrap items-center gap-6 bg-background p-6">
          <WatercolorBlot variant="splash" size={220} />
          <WatercolorBlot variant="wash" size={200} />
          <WatercolorBlot variant="drift" size={210} />
        </div>

  },
  {
    name: 'Transparent background check',
    description:
    'Each variant on a checkerboard (blend off) and on sage — any non-transparent box would show as a solid rectangle',
    render: () =>
    <div className="flex w-full flex-col gap-4 p-6">
          <div
        className="flex flex-wrap items-center gap-6 p-6"
        style={{
          backgroundColor: '#FFFFFF',
          backgroundImage:
          'linear-gradient(45deg, #D9D9D9 25%, transparent 25%), linear-gradient(-45deg, #D9D9D9 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #D9D9D9 75%), linear-gradient(-45deg, transparent 75%, #D9D9D9 75%)',
          backgroundSize: '20px 20px',
          backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0'
        }}>
        
            {(['splash', 'wash', 'drift'] as const).map((v) =>
        <WatercolorBlot key={v} variant={v} size={150} blend={false} />
        )}
          </div>
          <div className="flex flex-wrap items-center gap-6 bg-card p-6">
            {(['splash', 'wash', 'drift'] as const).map((v) =>
        <WatercolorBlot key={v} variant={v} size={150} blend={false} />
        )}
          </div>
        </div>

  },
  {
    name: 'Transparency',
    description: 'Opacity steps from full to faint',
    render: () =>
    <div className="flex flex-wrap items-center gap-4 bg-background p-6">
          {[1, 0.75, 0.5, 0.25].map((o) =>
      <div key={o} className="flex flex-col items-center gap-2">
              <WatercolorBlot variant="splash" size={170} opacity={o} />
              <span className="text-xs text-muted-text">{Math.round(o * 100)}%</span>
            </div>
      )}
        </div>

  },
  {
    name: 'Rotate & flip',
    description: 'One blob turned into four different-looking washes',
    render: () =>
    <div className="grid grid-cols-2 gap-6 bg-background p-6">
          <WatercolorBlot variant="drift" size={200} />
          <WatercolorBlot variant="drift" size={200} flip />
          <WatercolorBlot variant="drift" size={200} flipVertical rotate={15} />
          <WatercolorBlot variant="drift" size={200} flip flipVertical rotate={-25} />
        </div>

  },
  {
    name: 'Stacked blobs',
    description: 'Blobs layered on top of each other — overlaps deepen like real pigment',
    render: () =>
    <div className="relative isolate h-80 w-full max-w-lg overflow-hidden bg-background">
          <WatercolorBlot variant="wash" position="center" size={380} layer={0} />
          <WatercolorBlot variant="splash" position="top-left" size={300} layer={1} rotate={-10} className="!left-6 !top-4" />
          <WatercolorBlot variant="drift" position="bottom-right" size={260} layer={2} flip opacity={0.8} className="!bottom-2 !right-4" />
        </div>

  },
  {
    name: 'Blob + botanical',
    description: 'Blob stack under a eucalyptus sprig',
    render: () =>
    <div className="relative isolate h-80 w-96 bg-background">
          <WatercolorBlot variant="wash" position="center" size={320} layer={0} />
          <WatercolorBlot variant="splash" position="center" size={240} layer={1} rotate={20} opacity={0.7} />
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
            <BotanicalDecoration variant="eucalyptus" size={220} rotate={-10} />
          </div>
        </div>

  },
  {
    name: 'Section accents',
    description: 'Blobs and botanicals in section corners behind content',
    render: () =>
    <section className="relative isolate w-full max-w-2xl overflow-hidden bg-background px-10 py-20 text-center">
          <WatercolorBlot variant="splash" position="top-left" size={340} />
          <WatercolorBlot variant="drift" position="bottom-right" size={320} flip layer={1} />
          <WatercolorBlot variant="wash" position="bottom-right" size={220} layer={0} opacity={0.6} className="!-bottom-4 !right-40" />
          <BotanicalDecoration variant="corner" position="top-left" size={160} />
          <h2 className="text-5xl text-text" style={{ fontFamily: 'Allura, cursive' }}>
            Prost auf euch
          </h2>
          <p className="mt-3 text-text">Wir bringen die Bar zu deinem Fest.</p>
        </section>

  }]

};

export default previews;