import { WatercolorBackground } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

function SampleContent({ title }: {title: string;}) {
  return (
    <div className="mx-auto flex max-w-2xl flex-col items-center gap-3 px-6 py-24 text-center">
      <p className="text-xs uppercase tracking-[0.25em] text-muted-text">Zum Wohl Mobil</p>
      <h2 className="text-5xl text-text md:text-6xl" style={{ fontFamily: 'Allura, cursive' }}>
        {title}
      </h2>
      <p className="max-w-md text-text">
        Wir bringen die mobile Bar direkt zu deinem Fest. Wagenmiete & Dekoration inklusive.
      </p>
    </div>);

}

const previews: ComponentPreviewModule = {
  componentName: 'WatercolorBackground',
  importPath: 'components/WatercolorBackground',
  previews: [
  {
    name: 'Hero',
    description: 'Splash blot + garland top-left, drift blot + corner sprig bottom-right',
    render: () =>
    <WatercolorBackground as="section" layout="hero">
          <SampleContent title="Zum Wohl!" />
        </WatercolorBackground>

  },
  {
    name: 'Corners',
    description: 'Default — blot + botanical pairings in opposite corners',
    render: () =>
    <WatercolorBackground as="section">
          <SampleContent title="Unsere Getränke" />
        </WatercolorBackground>

  },
  {
    name: 'Right side',
    description: 'A single pairing on one edge, for quieter sections',
    render: () =>
    <WatercolorBackground as="section" layout="right">
          <SampleContent title="So funktioniert's" />
        </WatercolorBackground>

  },
  {
    name: 'Corners, mirrored',
    description: 'Same corners layout flipped left ↔ right for the next section',
    render: () =>
    <WatercolorBackground as="section" mirror>
          <SampleContent title="Unsere Preise" />
        </WatercolorBackground>

  },
  {
    name: 'Faded',
    description: 'Corners layout with botanicalOpacity 0.45 and blotOpacity 0.6 — for text-heavy sections',
    render: () =>
    <WatercolorBackground as="section" botanicalOpacity={0.45} blotOpacity={0.6}>
          <SampleContent title="Anfrage absenden" />
        </WatercolorBackground>

  },
  {
    name: 'Blots only',
    description: 'Washes without leaves — use between botanical-heavy sections',
    render: () =>
    <WatercolorBackground as="section" layout="blots-only">
          <SampleContent title="Individuelles Angebot" />
        </WatercolorBackground>

  }]

};

export default previews;