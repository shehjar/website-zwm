# WatercolorBackground

A full-width section wrapper that places the real watercolor blots (**WatercolorBlot**) and eucalyptus sprigs (**BotanicalDecoration**) in the background. Every composition puts a blot underneath and lays a sprig over it, so the leaves look painted onto the wash. Decorations sit behind the content (`-z-10`), use `aria-hidden`, and ignore pointer events. They are flat: no shadows and no gradients.

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| `layout` | `'hero' \| 'corners' \| 'left' \| 'right' \| 'blots-only' \| 'none'` | `'corners'` | Preset arrangement (see below) |
| `mobile` | `'scale' \| 'hide'` | `'scale'` | `scale` shrinks pieces to about 55% on phones. `hide` removes them below `md` |
| `mirror` | `boolean` | `false` | Flips the whole composition left ↔ right. For example, `corners` + `mirror` puts the pairings at top-right and bottom-left |
| `mirrorVertical` | `boolean` | `false` | Flips the whole composition top ↔ bottom |
| `botanicalOpacity` | `number` | `1` | Fades every sprig in the layout (multiplier, 0 to 1) |
| `blotOpacity` | `number` | `1` | Fades every blot in the layout (multiplier, 0 to 1) |
| `paperColor` | `string` | `'var(--background)'` | Base color |
| `as` | `'div' \| 'section' \| 'header' \| 'footer' \| 'main'` | `'div'` | Wrapper element |
| `className` | `string` | – | Wrapper classes |
| `contentClassName` | `string` | – | Content layer classes |
| `children` | `ReactNode` | – | Section content |

## Layouts
- `hero`: splash blot + garland at top-left, drift blot + corner sprig at bottom-right. Use it only for the opening section.
- `corners`: a drift blot + eucalyptus at top-left, and a splash blot + faded dark sprig at bottom-right. A general-purpose section background.
- `left`: a drift blot + the upright twin branch. `right`: a splash blot + the slender branch. Use these for quieter sections such as the process steps or the form.
- `blots-only`: washes with no leaves. A breather between busier sections.
- `none`: a plain paper background.

## Usage
```tsx
<WatercolorBackground as="section" layout="hero">
  <div className="mx-auto max-w-5xl px-6 py-24">…</div>
</WatercolorBackground>
```

## Guidelines
- Use them sparingly. Don't give every section leaves. Alternate `corners` / `left` / `right` / `blots-only` / `none` down the page.
- Toggle `mirror` on alternating sections that share a layout, so they don't look repeated.
- Behind text-heavy sections, lower `botanicalOpacity` (about 0.5) instead of removing the leaves.
- Use `mobile="hide"` behind dense text, such as the inquiry form or pricing.
- For a one-off placement, use `WatercolorBlot` and `BotanicalDecoration` directly inside a `relative isolate` parent.
