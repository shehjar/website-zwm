# SiteHeader

Global header for every page: Logo (links home), the six nav links with the underline-and-dot active marker (desktop, `lg+`), the JETZT ANFRAGEN pill CTA (`sm+`), and the MobileMenuOverlay (below `lg`). Desktop nav (logo, six links, CTA) is always visible from `lg` (≥1024px). Below `lg` it collapses into MobileMenuOverlay. Windows laptops with 125–150% display scaling often have effective widths of ~1100–1280px, so the full navigation must fit at `lg` — never push the switch back to `xl`.

To fit at 1024px the header scales fluidly: links use NavLink `sm` sizing with `lg:gap-5` (full `md` sizing and `xl:gap-8` at `xl`), the logo is `h-12` at `lg` and `h-16` at `xl`, the CTA is PillButton `sm` at `lg` and `md` sizing at `xl`, container padding is `px-6 xl:px-10`, and links are `whitespace-nowrap`.

Composes Logo, NavLink, PillButton and MobileMenuOverlay — don't rebuild these inline.

## Props
| Prop | Type | Default |
|---|---|---|
| `activeHref` | `string` | `'/'` |
| `links` | `{ label, href }[]` | Start, Preise, Rezepte, Mietablauf, Über uns, Kontakt |
| `ctaLabel` | `string` | `'Jetzt anfragen'` (rendered uppercase) |
| `ctaHref` | `string` | `'/kontakt'` |
| `sticky` | `boolean` | `true` |
| `className` | `string` | — |

## Usage
```tsx
<SiteHeader activeHref="/preise" />
```
