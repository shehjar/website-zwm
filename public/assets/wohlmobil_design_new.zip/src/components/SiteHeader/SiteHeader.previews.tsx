import { SiteHeader } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'SiteHeader',
  importPath: 'components/SiteHeader',
  previews: [
  {
    name: 'Start active',
    description: 'Logo, nav, JETZT ANFRAGEN CTA; full nav from lg (≥1024px), menu icon below',
    render: () =>
    <div className="w-full">
          <SiteHeader activeHref="/" sticky={false} />
        </div>

  },
  {
    name: 'Preise active',
    description: 'Active marker on PREISE',
    render: () =>
    <div className="w-full">
          <SiteHeader activeHref="/preise" sticky={false} />
        </div>

  }]

};

export default previews;