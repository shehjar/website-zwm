import { PageHeader } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const HERO = "/fa4619cb-8c92-4f8b-840c-7c0f34eb589e.jpg";


const TITLE_LETTERING = "/text_header.svg";


const previews: ComponentPreviewModule = {
  componentName: 'PageHeader',
  importPath: 'components/PageHeader',
  previews: [
  {
    name: 'Homepage hero',
    description: 'Simple hero: official lettering, one CTA, torn-edge photo — no subline',
    render: () =>
    <PageHeader
      title="Mobile Bar für besondere Momente"
      titleImageSrc={TITLE_LETTERING}
      ctaLabel="Jetzt anfragen"
      imageSrc={HERO}
      imageAlt="Unsere mobile Aperol-Spritz-Bar mit Eukalyptus-Dekoration auf einer Gartenhochzeit" />


  },
  {
    name: 'Page banner',
    description: 'Centered banner for inner pages (Preise)',
    render: () => <PageHeader title="Unsere Preise" ctaLabel="Jetzt anfragen" />
  },
  {
    name: 'Banner with subline',
    description: 'Rezepte page header',
    render: () =>
    <PageHeader
      title="Unsere Getränke"
      subline="Klassisch, fruchtig oder mit dem gewissen Extra – entdecke unsere Aperol-Kreationen und lass dich inspirieren." />


  }]

};

export default previews;