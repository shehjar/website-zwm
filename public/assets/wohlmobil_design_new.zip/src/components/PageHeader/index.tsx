import React from 'react';
import { PillButton } from '../PillButton';
import { TornEdgeImage } from '../TornEdgeImage';
import { WatercolorBlot } from '../WatercolorBlot';
import { BotanicalDecoration } from '../BotanicalDecoration';

export interface PageHeaderProps {
  /** H1 — rendered in Allura script (emotional display heading) */
  title: string;
  /** Optional lettering artwork (SVG) shown instead of the typeset title. `title` stays the accessible H1 text. */
  titleImageSrc?: string;
  /** Supporting line under the title */
  subline?: React.ReactNode;
  ctaLabel?: string;
  ctaHref?: string;
  /** Optional photo — switches to the hero layout (homepage): photo bleeds off the right edge on desktop */
  imageSrc?: string;
  imageAlt?: string;
  /** Show watercolor + eucalyptus decoration behind the header */
  decorated?: boolean;
  className?: string;
}

export function PageHeader({
  title,
  titleImageSrc,
  subline,
  ctaLabel,
  ctaHref = '/kontakt',
  imageSrc,
  imageAlt = '',
  decorated = true,
  className = ''
}: PageHeaderProps) {
  const isHero = Boolean(imageSrc);

  return (
    <section className={`relative isolate w-full overflow-hidden bg-background ${className}`}>
      {decorated && (isHero ? <HeroDecoration /> : <BannerDecoration />)}

      {/* Desktop hero photo — bleeds off the right edge; the right tear is cropped by the viewport */}
      {isHero && imageSrc &&
      <div className="absolute right-[-48px] top-1/2 hidden w-[54%] max-w-[860px] -translate-y-1/2 lg:block">
          {decorated &&
        <BotanicalDecoration
          variant="branch"
          position="bottom-left"
          size={220}
          rotate={-18}
          opacity={0.9}
          className="!-bottom-16 !-left-20" />

        }
          <TornEdgeImage src={imageSrc} alt={imageAlt} aspectRatio="4 / 3" roughness="medium" seed={11} shadow={false} />
        </div>
      }

      <div
        className={`relative mx-auto w-full max-w-7xl px-5 md:px-8 ${
        isHero ?
        'grid items-center gap-10 py-10 sm:py-16 lg:min-h-[640px] lg:grid-cols-2 lg:py-20' :
        'py-16 text-center md:py-24'}`
        }>
        
        <div className={isHero ? 'text-center lg:pl-12 xl:pl-20' : 'mx-auto max-w-3xl'}>
          {titleImageSrc ?
          <h1 className="m-0">
              <img
              src={titleImageSrc}
              alt={title}
              className="mx-auto block h-auto w-full max-w-[320px] sm:max-w-[440px] lg:max-w-[500px]" />
            
            </h1> :

          <h1
            className="text-6xl leading-[1.05] text-text md:text-7xl lg:text-8xl"
            style={{ fontFamily: 'Allura, cursive', fontWeight: 400 }}>
            
              {title}
            </h1>
          }
          {subline &&
          <p className="mx-auto mt-6 max-w-2xl text-lg font-light leading-relaxed text-text md:text-xl">
              {subline}
            </p>
          }
          {ctaLabel &&
          <div className="mt-8">
              <PillButton href={ctaHref} size="lg">
                {ctaLabel}
              </PillButton>
            </div>
          }
        </div>

        {/* Mobile / tablet hero photo — stacked below the lettering */}
        {isHero && imageSrc &&
        <div className="relative isolate mx-auto w-full max-w-xl lg:hidden">
            {decorated &&
          <BotanicalDecoration
            variant="branch"
            position="bottom-left"
            size={200}
            rotate={-18}
            mobileScale={0.6}
            className="!-bottom-8 !-left-6" />

          }
            <TornEdgeImage src={imageSrc} alt={imageAlt} aspectRatio="4 / 3" seed={11} shadow={false} />
          </div>
        }
      </div>
    </section>);

}

/**
 * Hero: one tall eucalyptus branch framing the left edge with a watercolor
 * wash pooling beneath it. Nothing in the top-left corner (keeps the logo/nav
 * clear) and nothing behind the photo (it carries itself).
 */
function HeroDecoration() {
  return (
    <>
      <WatercolorBlot
        variant="splash"
        position="bottom-left"
        size={640}
        opacity={0.6}
        className="!-bottom-28 !-left-32" />
      
      <WatercolorBlot
        variant="wash"
        position="top-left"
        size={420}
        opacity={0.5}
        layer={1}
        className="!-left-24 !top-[8%]" />
      
      <BotanicalDecoration
        variant="twin"
        position="top-left"
        size={300}
        opacity={0.9}
        mobileScale={0.4}
        className="!-left-16 !top-6 lg:!-left-10 lg:!top-[10%]" />
      
    </>);

}

/** Inner-page banners: splash + garland top-left, drift wash bottom-right. */
function BannerDecoration() {
  return (
    <>
      <WatercolorBlot variant="splash" position="top-left" size={520} opacity={0.8} />
      <BotanicalDecoration variant="garland" position="top-left" size={260} mobileScale={0.45} />
      <WatercolorBlot variant="drift" position="bottom-right" size={360} flip opacity={0.7} />
    </>);

}