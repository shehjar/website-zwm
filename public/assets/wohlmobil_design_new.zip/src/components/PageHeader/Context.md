# PageHeader

Top-of-page section with the page's single H1 in Allura script, an optional subline in Jost, an optional pill CTA and soft watercolor/eucalyptus decoration. Use it once per page.

- **Banner** (no `imageSrc`): centered. Use it for Preise, Rezepte, Mietablauf, Über uns and Kontakt.
- **Hero** (with `imageSrc`): use it on the homepage. On desktop (`lg+`) the lettering and button sit on the left. The torn-edge photo fills the right ~54% and runs off the right edge of the screen, so its left and bottom tears read as intentional. Never fade the photo with a gradient. On phones and tablets it stacks lettering → button → photo, with tighter top padding so the button is visible without scrolling. Keep this order.

Decoration shows on every page and every screen size. It shrinks smoothly on phones instead of hiding, and always sits behind content:
- **Banner:** watercolor splash + garland top-left, drift wash bottom-right.
- **Hero:** one tall eucalyptus branch (`twin`) framing the left edge, with a pale wash and a watercolor splash pooling beneath it toward the next section. A slender branch tucks behind the photo's bottom-left corner to tie the photo to the lettering. The top-left corner stays empty so it doesn't clash with the logo and nav. Nothing sits behind the photo itself.

## Props
| Prop | Type | Default |
|---|---|---|
| `title` | `string` | — (H1) |
| `titleImageSrc` | `string` | — (lettering SVG; `title` becomes its alt text) |
| `subline` | `ReactNode` | — |
| `ctaLabel` / `ctaHref` | `string` | — / `'/kontakt'` |
| `imageSrc` / `imageAlt` | `string` | — |
| `decorated` | `boolean` | `true` |
| `className` | `string` | — |

## Content mapping
| Page | title | subline | CTA |
|---|---|---|---|
| Start | Mobile Bar für besondere Momente + `titleImageSrc="https://cdn.magicpatterns.com/uploads/sJZ5DWdv9tCu4zHVNXM7fx/text_header.svg"` | — (keep the homepage hero simple: no subline) | Jetzt anfragen + hero photo |

On the homepage, always use the official lettering SVG — don't retype the title in Allura, and don't add a subline under it.
| Preise | Unsere Preise | — | Jetzt anfragen |
| Rezepte | Unsere Getränke | Klassisch, fruchtig … | — |
| Mietablauf | So funktioniert die Miete | In 4 einfachen Schritten zu deiner eigenen Spritz-Bar. | — |
| Über uns | Wer wir sind | Leidenschaft für besondere Momente … | — |
| Kontakt | Anfrageformular | Erzähl uns von deinem Fest … | — |
