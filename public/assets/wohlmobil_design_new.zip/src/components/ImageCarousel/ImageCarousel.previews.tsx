import { ImageCarousel } from './index';
import type { ImageCarouselImage } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const images: ImageCarouselImage[] = [
{
  src: "/2d2a0649-ff5f-49c6-baf7-11fa1d576d18.jpg",
  alt: 'Mobile Bar mit Lichterketten bei einer Gartenparty',
  caption: 'Unsere mobile Bar im Garten'
},
{
  src: "/4ec1d18b-1e10-49ed-ac68-a0bab393286f.jpg",
  alt: 'Hochzeitsgäste stoßen mit Sekt an',
  caption: 'Hochzeit am See'
},
{
  src: "/6e0aa7f0-3079-4227-b592-46a7449a56f7.jpg",
  alt: 'Barkeeper schenkt Spritz-Cocktails ein',
  caption: 'Frisch gemixte Drinks'
},
{
  src: "/7f534899-bfd6-4cc5-828b-6b0dda7793ef.jpg",
  alt: 'Mobile Bar auf einem Sommerfest',
  caption: 'Sommerfest in der Altstadt'
}];


const previews: ComponentPreviewModule = {
  componentName: 'ImageCarousel',
  importPath: 'components/ImageCarousel',
  previews: [
  {
    name: 'Single',
    description: 'One image at a time with captions, arrows, dots and counter',
    render: () =>
    <div className="w-full max-w-2xl">
          <ImageCarousel images={images} showCounter />
        </div>

  },
  {
    name: 'Multi (Gallery Row)',
    description: 'Peeking multi-image row for event galleries',
    render: () =>
    <div className="w-full max-w-5xl">
          <ImageCarousel
        images={images.map(({ src, alt }) => ({ src, alt }))}
        variant="multi"
        aspect="portrait" />
      
        </div>

  },
  {
    name: 'Autoplay',
    description: 'Advances every 3s, pauses on hover/focus',
    render: () =>
    <div className="w-full max-w-2xl">
          <ImageCarousel images={images} aspect="video" autoPlay={3000} />
        </div>

  },
  {
    name: 'Error & Empty',
    description: 'Broken image fallback and empty gallery state',
    render: () =>
    <div className="grid w-full max-w-3xl gap-6 sm:grid-cols-2">
          <ImageCarousel
        images={[{ src: 'https://invalid.example/missing.jpg', alt: 'Fehlendes Bild' }, images[0]]} />
      
          <ImageCarousel images={[]} />
        </div>

  }]

};

export default previews;