# ImageCarousel

Swipeable image carousel for bar cart and event galleries. Uses native horizontal scroll with snap points (touch swipe, trackpad, keyboard arrows) — no extra dependencies. Includes per-image loading skeleton, broken-image fallback, and an empty state.

## Props

| Prop | Type | Default | Description |
|---|---|---|---|
| `images` | `{ src: string; alt: string; caption?: string }[]` | — | Slides to show. Empty array renders an empty state. |
| `variant` | `'single' \| 'multi'` | `'single'` | `single`: one full-width slide. `multi`: peeking row (1 → 2 → 3 per view by breakpoint). |
| `aspect` | `'video' \| 'photo' \| 'square' \| 'portrait'` | `'photo'` | Slide aspect ratio (16:9, 4:3, 1:1, 3:4). |
| `showArrows` | `boolean` | `true` | Prev/next buttons (shown on hover, ≥ sm). |
| `showDots` | `boolean` | `true` | Pagination dots below. |
| `showCounter` | `boolean` | `false` | "2 / 4" badge top-right. |
| `autoPlay` | `number` | — | Interval in ms; pauses on hover/focus, loops at end. |
| `initialIndex` | `number` | `0` | Starting slide. |
| `onIndexChange` | `(index: number) => void` | — | Fires when active slide changes. |
| `label` | `string` | `'Bildergalerie'` | Accessible name of the carousel. |
| `className` | `string` | `''` | Extra classes on the wrapper. |

## Usage

```tsx
import { ImageCarousel } from 'components/ImageCarousel'

<ImageCarousel
  images={[
    { src: 'https://…/bar.jpg', alt: 'Mobile Bar', caption: 'Gartenparty' },
    { src: 'https://…/wedding.jpg', alt: 'Hochzeit' },
  ]}
  showCounter
/>

<ImageCarousel images={eventImages} variant="multi" aspect="portrait" />
```

## Notes
- Always provide meaningful `alt` text (German UI copy by default).
- Keyboard: focus the track and use ← / →.
