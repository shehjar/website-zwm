import React from 'react';
import { ConsentCheckbox } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'ConsentCheckbox',
  importPath: 'components/ConsentCheckbox',
  previews: [
  {
    name: 'Default',
    description: 'Unchecked DSGVO consent with link to Datenschutz page',
    render: () =>
    <div className="max-w-md">
          <ConsentCheckbox />
        </div>

  },
  {
    name: 'Checked',
    description: 'Consent given',
    render: () =>
    <div className="max-w-md">
          <ConsentCheckbox defaultChecked />
        </div>

  },
  {
    name: 'Error',
    description: 'Validation error when submitting without consent',
    render: () =>
    <div className="max-w-md">
          <ConsentCheckbox error="Bitte stimmen Sie der Datenschutzerklärung zu." />
        </div>

  },
  {
    name: 'Disabled',
    description: 'Disabled while the form is submitting',
    render: () =>
    <div className="max-w-md">
          <ConsentCheckbox defaultChecked disabled />
        </div>

  }]

};

export default previews;