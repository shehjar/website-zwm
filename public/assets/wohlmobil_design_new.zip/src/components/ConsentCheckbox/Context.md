# ConsentCheckbox

DSGVO-compliant consent checkbox for contact/inquiry forms, with an inline link to the Datenschutz (privacy policy) page. Required by default; never pre-check it in production (DSGVO requires active opt-in).

## Props

| Prop | Type | Default | Description |
|---|---|---|---|
| `checked` | `boolean` | – | Controlled state |
| `defaultChecked` | `boolean` | `false` | Uncontrolled initial state |
| `onChange` | `(checked: boolean) => void` | – | Change handler |
| `privacyHref` | `string` | `'/datenschutz'` | Datenschutz page URL |
| `privacyLinkLabel` | `string` | `'Datenschutzerklärung'` | Link text |
| `openInNewTab` | `boolean` | `true` | Opens link in new tab so form input isn't lost |
| `labelBefore` / `labelAfter` | `ReactNode` | German default copy | Text around the link |
| `required` | `boolean` | `true` | Adds asterisk + native `required` |
| `error` | `string` | – | Error message (sets `aria-invalid`, red styling) |
| `disabled` | `boolean` | `false` | Disabled state |
| `name` / `id` | `string` | `'consent'` / auto | Form field name / id |
| `className` | `string` | – | Wrapper classes |

## Usage

```tsx
import { ConsentCheckbox } from 'components/ConsentCheckbox'

const [consent, setConsent] = useState(false)
const [error, setError] = useState<string>()

<ConsentCheckbox
  checked={consent}
  onChange={(v) => { setConsent(v); setError(undefined) }}
  error={error}
/>
```

Clicking the link does not toggle the checkbox. Keyboard focus shows a visible ring on both the box and the link.
