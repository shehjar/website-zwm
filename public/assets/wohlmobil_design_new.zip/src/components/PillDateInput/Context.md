# PillDateInput

Pill-shaped (fully rounded) date field for selecting the **Wunschtermin** (desired event date) in booking/inquiry forms. Wraps the native `<input type="date">` with a leading calendar icon; clicking anywhere opens the browser's date picker.

## Props
- `label?: string` – visible label (default `"Wunschtermin"`)
- `value?: string` – ISO date `yyyy-mm-dd`
- `onChange?: (value: string) => void` – receives ISO date string
- `hint?: string` – helper text below the field
- `error?: string` – error message; sets red border + `aria-invalid`
- `size?: 'sm' | 'md' | 'lg'` – default `md`
- `shape?: 'pill' | 'rounded'` – default `pill`; `rounded` matches the Canva inquiry form
- `hideLabel?: boolean` – screen-reader-only label
- `required`, `disabled`, `min`, `max`, `name`, and other native input attributes
- `className` (input), `containerClassName` (wrapper)

## Usage
```tsx
const [date, setDate] = useState('')

<PillDateInput
  value={date}
  onChange={setDate}
  min={new Date().toISOString().slice(0, 10)}
  hint="Wann soll dein Fest stattfinden?"
  required
/>
```

## Notes
- Forwards ref to the underlying input.
- Use `min` set to today to prevent past dates.
