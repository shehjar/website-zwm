import React, { useState } from 'react';
import { PillDateInput } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

function Controlled(props: React.ComponentProps<typeof PillDateInput>) {
  const [value, setValue] = useState(props.value ?? '');
  return (
    <div style={{ width: '100%', maxWidth: 360 }}>
      <PillDateInput {...props} value={value} onChange={setValue} />
    </div>);

}

const today = new Date().toISOString().slice(0, 10);

const previews: ComponentPreviewModule = {
  componentName: 'PillDateInput',
  importPath: 'components/PillDateInput',
  previews: [
  {
    name: 'Default',
    description: 'Empty Wunschtermin field with hint',
    render: () => <Controlled hint="Wann soll Ihr Event stattfinden?" min={today} required />
  },
  {
    name: 'With value',
    description: 'Field with a selected date',
    render: () => <Controlled value="2026-12-12" />
  },
  {
    name: 'Error',
    description: 'Validation error state',
    render: () => <Controlled error="Bitte wählen Sie einen Wunschtermin." required />
  },
  {
    name: 'Sizes',
    description: 'Small, medium and large',
    render: () =>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, width: '100%', maxWidth: 360 }}>
          <Controlled size="sm" label="Klein" />
          <Controlled size="md" label="Mittel" />
          <Controlled size="lg" label="Groß" />
        </div>

  },
  {
    name: 'Disabled',
    description: 'Non-interactive state',
    render: () => <Controlled value="2026-11-20" disabled />
  }]

};

export default previews;