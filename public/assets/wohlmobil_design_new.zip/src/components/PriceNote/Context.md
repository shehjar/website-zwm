# PriceNote

Small, centered, muted line placed under the pricing grid for fine print (travel fees, VAT info).

## Props
- `items?: string[]` — text segments joined by a separator. Default: `["Inkl. 50 km Anfahrt, danach 3,00 € pro km", "Alle Preise inkl. MwSt."]`
- `children?: ReactNode` — custom content; overrides `items`.
- `separator?: string` — default `·`.
- `align?: 'center' | 'left'` — default `center`.
- `className?: string`

## Usage
```tsx
<PriceNote />
<PriceNote items={['Inkl. 30 km Anfahrt', 'Alle Preise inkl. MwSt.']} />
<PriceNote>Individuelle Angebote auf Anfrage.</PriceNote>
```
