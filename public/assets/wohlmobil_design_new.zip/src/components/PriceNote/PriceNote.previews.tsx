import { PriceNote } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'PriceNote',
  importPath: 'components/PriceNote',
  previews: [
  {
    name: 'Default',
    description: 'Standard note under the pricing grid',
    render: () => <PriceNote />
  },
  {
    name: 'Custom items',
    description: 'Three segments with custom text',
    render: () =>
    <PriceNote
      items={[
      'Inkl. 30 km Anfahrt',
      'Danach 2,50 € pro km',
      'Alle Preise inkl. MwSt.']
      } />


  },
  {
    name: 'Single line',
    description: 'Custom children content',
    render: () => <PriceNote>Individuelle Angebote auf Anfrage.</PriceNote>
  }]

};

export default previews;