// AUTO-GENERATED — do not edit manually.
// Re-run the design system builder to regenerate.

import type { ComponentPreviewModule } from './previewTypes';
import __AddOnPricePanelPreviews from './AddOnPricePanel/AddOnPricePanel.previews';
import __AddOnPriceRowPreviews from './AddOnPriceRow/AddOnPriceRow.previews';
import __BotanicalDecorationPreviews from './BotanicalDecoration/BotanicalDecoration.previews';
import __ConsentCheckboxPreviews from './ConsentCheckbox/ConsentCheckbox.previews';
import __DownloadCalloutPreviews from './DownloadCallout/DownloadCallout.previews';
import __FormStatusMessagePreviews from './FormStatusMessage/FormStatusMessage.previews';
import __ImageCarouselPreviews from './ImageCarousel/ImageCarousel.previews';
import __InfoTextBlockPreviews from './InfoTextBlock/InfoTextBlock.previews';
import __InquiryFormPreviews from './InquiryForm/InquiryForm.previews';
import __InstagramSectionPreviews from './InstagramSection/InstagramSection.previews';
import __LogoPreviews from './Logo/Logo.previews';
import __MobileMenuOverlayPreviews from './MobileMenuOverlay/MobileMenuOverlay.previews';
import __NavLinkPreviews from './NavLink/NavLink.previews';
import __PageHeaderPreviews from './PageHeader/PageHeader.previews';
import __PillButtonPreviews from './PillButton/PillButton.previews';
import __PillDateInputPreviews from './PillDateInput/PillDateInput.previews';
import __PillInputPreviews from './PillInput/PillInput.previews';
import __PillSelectPreviews from './PillSelect/PillSelect.previews';
import __PillTextareaPreviews from './PillTextarea/PillTextarea.previews';
import __PriceNotePreviews from './PriceNote/PriceNote.previews';
import __PricingTierCardPreviews from './PricingTierCard/PricingTierCard.previews';
import __ProcessStepPreviews from './ProcessStep/ProcessStep.previews';
import __RecipeCardPreviews from './RecipeCard/RecipeCard.previews';
import __ScriptBannerPreviews from './ScriptBanner/ScriptBanner.previews';
import __SectionHeadingPreviews from './SectionHeading/SectionHeading.previews';
import __SiteFooterPreviews from './SiteFooter/SiteFooter.previews';
import __SiteHeaderPreviews from './SiteHeader/SiteHeader.previews';
import __TornEdgeImagePreviews from './TornEdgeImage/TornEdgeImage.previews';
import __WatercolorBackgroundPreviews from './WatercolorBackground/WatercolorBackground.previews';
import __WatercolorBlotPreviews from './WatercolorBlot/WatercolorBlot.previews';
const __contextMd: Record<string, string> = {
  "AddOnPricePanel": `# AddOnPricePanel

Pale sage card that groups multiple add-on price rows under a shared heading. Used on pricing pages to list optional extras.

## Props
- \`heading: string\` – panel title (rendered as h3, labels the section)
- \`description?: string\` – short intro under the heading
- \`items?: { id?, label, description?, price, unit? }[]\` – built-in rows, divided by sage lines
- \`children?: ReactNode\` – custom rows (e.g. \`AddOnPriceRow\`) rendered in a divided list
- \`footnote?: string\` – small note at the bottom (e.g. "zzgl. MwSt.")
- \`className?: string\`

## Usage
\`\`\`tsx
<AddOnPricePanel
  heading="Zusatzleistungen"
  items={[
    { label: 'Barkeeper', price: '45 €', unit: '/ Std.' },
    { label: 'Eiswürfel', price: '12 €' },
  ]}
  footnote="Alle Preise zzgl. MwSt."
/>
\`\`\`
`,
  "AddOnPriceRow": `# AddOnPriceRow

Single line item that pairs an add-on name with its price. Used inside the add-on panel to list optional extras (e.g. Sektempfang, extra Barkeeper).

## Props
| Prop | Type | Default | Description |
|---|---|---|---|
| \`name\` | \`ReactNode\` | — | Add-on name (required) |
| \`price\` | \`number \\| string\` | — | Numbers formatted as EUR (de-DE, e.g. \`4,50 €\`); strings render as-is (e.g. "auf Anfrage") |
| \`description\` | \`ReactNode\` | — | Secondary line under the name |
| \`unit\` | \`string\` | — | Suffix after price, e.g. \`/ Gast\` |
| \`icon\` | \`ReactNode\` | — | Leading icon in a round neutral badge |
| \`highlighted\` | \`boolean\` | \`false\` | Bold styling for totals/selected items |
| \`divider\` | \`boolean\` | \`true\` | Bottom border (auto-removed on last row) |
| \`className\` | \`string\` | — | Merged via tailwind-merge |

Also exports \`formatPrice(price)\`.

## Usage
\`\`\`tsx
import { WineIcon } from 'lucide-react'
import { AddOnPriceRow } from 'components/AddOnPriceRow'

<div className="rounded-xl border border-neutral-200 bg-white px-4">
  <AddOnPriceRow icon={<WineIcon className="h-4 w-4" />} name="Sektempfang" price={4.5} unit="/ Gast" />
  <AddOnPriceRow name="Summe Extras" price={37} highlighted />
</div>
\`\`\`
`,
  "BotanicalDecoration": `# BotanicalDecoration

Decorative watercolor eucalyptus illustrations on transparent backgrounds. These are real brand assets: never redraw or substitute them. Use them as accents around page sections. They are decorative only (\`aria-hidden\`, \`pointer-events-none\`). Corner positions sit behind the content (\`-z-10\`), so give the parent \`relative isolate\`.

## Variants
- \`eucalyptus\`: a pale, round-leaf branch on a diagonal
- \`branch\`: a slender, airy sprig sweeping diagonally
- \`corner\`: an L-shaped corner sprig that fits bottom-left. Flip or rotate it for other corners
- \`sprig\`: a short sprig with dark, saturated leaves. It's the strongest accent, so fade it behind text
- \`twin\`: a tall, upright double branch. Good on the side edges
- \`garland\`: a dense top-left corner garland. Use it in the hero or a header corner

Asset URLs are exported as \`BOTANICAL_SOURCES\`.

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| \`variant\` | see above | \`'eucalyptus'\` | Illustration |
| \`position\` | \`'top-left' \\| 'top-right' \\| 'bottom-left' \\| 'bottom-right' \\| 'inline'\` | \`'inline'\` | Corner positions are \`absolute\` |
| \`size\` | \`number\` | \`220\` | Width in px |
| \`rotate\` | \`number\` | \`0\` | Degrees, any value (positive = clockwise) |
| \`flip\` | \`boolean\` | \`false\` | Mirror horizontally (left ↔ right) |
| \`flipVertical\` | \`boolean\` | \`false\` | Mirror vertically (top ↔ bottom). Combine with \`flip\` to move \`corner\`/\`garland\` into any corner |
| \`opacity\` | \`number\` | \`1\` | Transparency from 0 to 1, clamped. Suggested: about 0.6 for accents beside content, 0.25–0.4 behind text, 0.15 for faint texture |
| \`mobileScale\` | \`number\` | \`0.55\` | Smallest scale on phones. The width shrinks smoothly from \`size\` (≥ ~1100px) to \`size × mobileScale\` (~375px). \`1\` = fixed size |
| \`className\` | \`string\` | — | e.g. \`!-top-8 md:!-top-14\` to nudge offsets per breakpoint |

Decorations should stay visible on mobile. Let \`mobileScale\` shrink them rather than hiding them with \`hidden md:block\`.

## Corner recipes (\`corner\` sprig, drawn for bottom-left)
- bottom-left: none · bottom-right: \`flip\` · top-left: \`flipVertical\` · top-right: \`flip flipVertical\`
- \`garland\` is drawn for top-left: top-right \`flip\` · bottom-left \`flipVertical\` · bottom-right both

Rotation is applied before mirroring. Small rotations (±10–25°) make repeated sprigs look less mechanical.

## Usage
\`\`\`tsx
<section className="relative isolate overflow-hidden">
  <BotanicalDecoration variant="garland" position="top-left" opacity={0.5} />
  <BotanicalDecoration variant="sprig" position="bottom-right" rotate={160} opacity={0.3} />
  ...
</section>
\`\`\`
`,
  "ConsentCheckbox": `# ConsentCheckbox

DSGVO-compliant consent checkbox for contact/inquiry forms, with an inline link to the Datenschutz (privacy policy) page. Required by default; never pre-check it in production (DSGVO requires active opt-in).

## Props

| Prop | Type | Default | Description |
|---|---|---|---|
| \`checked\` | \`boolean\` | – | Controlled state |
| \`defaultChecked\` | \`boolean\` | \`false\` | Uncontrolled initial state |
| \`onChange\` | \`(checked: boolean) => void\` | – | Change handler |
| \`privacyHref\` | \`string\` | \`'/datenschutz'\` | Datenschutz page URL |
| \`privacyLinkLabel\` | \`string\` | \`'Datenschutzerklärung'\` | Link text |
| \`openInNewTab\` | \`boolean\` | \`true\` | Opens link in new tab so form input isn't lost |
| \`labelBefore\` / \`labelAfter\` | \`ReactNode\` | German default copy | Text around the link |
| \`required\` | \`boolean\` | \`true\` | Adds asterisk + native \`required\` |
| \`error\` | \`string\` | – | Error message (sets \`aria-invalid\`, red styling) |
| \`disabled\` | \`boolean\` | \`false\` | Disabled state |
| \`name\` / \`id\` | \`string\` | \`'consent'\` / auto | Form field name / id |
| \`className\` | \`string\` | – | Wrapper classes |

## Usage

\`\`\`tsx
import { ConsentCheckbox } from 'components/ConsentCheckbox'

const [consent, setConsent] = useState(false)
const [error, setError] = useState<string>()

<ConsentCheckbox
  checked={consent}
  onChange={(v) => { setConsent(v); setError(undefined) }}
  error={error}
/>
\`\`\`

Clicking the link does not toggle the checkbox. Keyboard focus shows a visible ring on both the box and the link.
`,
  "DownloadCallout": `# DownloadCallout

A thin-bordered rounded box with a file icon, a short text and the "Herunterladen" pill button. Use it on the Preise page for the price list.

By default it links to the current Preisliste (\`PRICE_LIST_URL\`, an A4 image). When the real PDF is exported from Canva, replace \`PRICE_LIST_URL\` or pass \`href\` + \`fileName\`. If \`href\` is empty, the button is disabled and the box shows "Bald verfügbar".

## Props
| Prop | Type | Default |
|---|---|---|
| \`text\` | \`string\` | \`'Unsere Preisliste herunterladen'\` (switch back to "…als PDF…" once the file is a real PDF) |
| \`buttonLabel\` | \`string\` | \`'Herunterladen'\` |
| \`href\` | \`string\` | \`PRICE_LIST_URL\` |
| \`fileName\` | \`string\` | \`'Zum-Wohl-Mobil-Preisliste.png'\` |
| \`meta\` | \`string\` | \`'Preisliste · A4'\` |

Keep the price list in sync with the website prices (250 / 400 / 550 €, Wagenmiete 120 €, Dekoration 30 €, 3,00 € per km beyond 50 km).
`,
  "FormStatusMessage": `# FormStatusMessage

Feedback banner shown above/below a form after submission. Supports success, error, info and loading states, animates in/out with framer-motion, and announces itself to screen readers (\`role="alert"\` for errors, \`role="status"\` otherwise).

## Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| \`status\` | \`'success' \\| 'error' \\| 'info' \\| 'loading'\` | — | Visual + semantic state |
| \`title\` | \`string\` | — | Bold headline |
| \`message\` | \`ReactNode\` | — | Supporting text |
| \`visible\` | \`boolean\` | \`true\` | Toggle with exit animation |
| \`onDismiss\` | \`() => void\` | — | Renders a close button when set |
| \`action\` | \`ReactNode\` | — | Optional action (e.g. retry button) |
| \`className\` | \`string\` | — | Extra classes (merged via tailwind-merge) |

## Usage

\`\`\`tsx
import { FormStatusMessage } from 'components/FormStatusMessage'

<FormStatusMessage
  status="success"
  title="Vielen Dank!"
  message="Wir melden uns innerhalb von 24 Stunden."
/>

<FormStatusMessage
  status="error"
  title="Senden fehlgeschlagen"
  message="Bitte versuchen Sie es erneut."
  onDismiss={() => setStatus(null)}
/>
\`\`\`

Use \`status="loading"\` while the request is in flight, then switch to \`success\` or \`error\`.
`,
  "ImageCarousel": `# ImageCarousel

Swipeable image carousel for bar cart and event galleries. Uses native horizontal scroll with snap points (touch swipe, trackpad, keyboard arrows) — no extra dependencies. Includes per-image loading skeleton, broken-image fallback, and an empty state.

## Props

| Prop | Type | Default | Description |
|---|---|---|---|
| \`images\` | \`{ src: string; alt: string; caption?: string }[]\` | — | Slides to show. Empty array renders an empty state. |
| \`variant\` | \`'single' \\| 'multi'\` | \`'single'\` | \`single\`: one full-width slide. \`multi\`: peeking row (1 → 2 → 3 per view by breakpoint). |
| \`aspect\` | \`'video' \\| 'photo' \\| 'square' \\| 'portrait'\` | \`'photo'\` | Slide aspect ratio (16:9, 4:3, 1:1, 3:4). |
| \`showArrows\` | \`boolean\` | \`true\` | Prev/next buttons (shown on hover, ≥ sm). |
| \`showDots\` | \`boolean\` | \`true\` | Pagination dots below. |
| \`showCounter\` | \`boolean\` | \`false\` | "2 / 4" badge top-right. |
| \`autoPlay\` | \`number\` | — | Interval in ms; pauses on hover/focus, loops at end. |
| \`initialIndex\` | \`number\` | \`0\` | Starting slide. |
| \`onIndexChange\` | \`(index: number) => void\` | — | Fires when active slide changes. |
| \`label\` | \`string\` | \`'Bildergalerie'\` | Accessible name of the carousel. |
| \`className\` | \`string\` | \`''\` | Extra classes on the wrapper. |

## Usage

\`\`\`tsx
import { ImageCarousel } from 'components/ImageCarousel'

<ImageCarousel
  images={[
    { src: 'https://…/bar.jpg', alt: 'Mobile Bar', caption: 'Gartenparty' },
    { src: 'https://…/wedding.jpg', alt: 'Hochzeit' },
  ]}
  showCounter
/>

<ImageCarousel images={eventImages} variant="multi" aspect="portrait" />
\`\`\`

## Notes
- Always provide meaningful \`alt\` text (German UI copy by default).
- Keyboard: focus the track and use ← / →.
`,
  "InfoTextBlock": `# InfoTextBlock

A titled text section. It has an uppercase Jost heading, an optional intro, an optional list of items (each with an icon and a short bold lead-in) and free-form paragraphs.

Use it for:
- **Preise**: "Was ist in der Getränkepauschale enthalten?" with 3 icon items (GlassWater, HandPlatter, Truck).
- **Über uns**: story paragraphs, passed as \`children\` with \`variant="plain"\`.

## Props
| Prop | Type | Default |
|---|---|---|
| \`title\` | \`string\` | — |
| \`intro\` | \`ReactNode\` | — |
| \`items\` | \`{ icon?, title?, text }[]\` | — |
| \`children\` | \`ReactNode\` | — |
| \`variant\` | \`'card' \\| 'plain'\` | \`'card'\` (pale sage, 32px radius) |
| \`as\` | \`'h2' \\| 'h3'\` | \`'h2'\` |

Tip: break long paragraphs into items with a bold lead-in. Visitors scan prices pages and don't read them word for word.
`,
  "InquiryForm": `# InquiryForm

The complete Anfrageformular, composed from PillInput, PillDateInput, PillSelect, PillTextarea, ConsentCheckbox, PillButton and FormStatusMessage. Use this instead of hand-assembling the fields.

## Fields (in order)
Name*, Telefonnummer*, E-Mail-Adresse* · Wunschtermin* (date, no past dates), Art der Veranstaltung* (dropdown), Ort der Veranstaltung*, Personenanzahl* (number) · message (optional, 1000 chars) · DSGVO consent*.

Desktop pairs related fields in two columns; mobile stacks them.

## Behaviour
- Inline German "du" validation on submit; focus jumps to the first invalid field.
- Sending state disables all fields and shows a spinner on the button.
- Error → dismissible FormStatusMessage. Success → replaces the form with a warm thank-you card that says it's **unverbindlich** and **noch keine Buchung**.
- The non-binding note always sits under the submit button.

## Delivery
Inquiries go to \`INQUIRY_RECIPIENT = 'zumwohlmobil@gmail.com'\` via FormSubmit (\`sendViaFormSubmit\`, no backend needed). The email has a readable subject ("Neue Anfrage: Hochzeit am 12.06.2027"), and *Reply* goes straight to the customer.

**One-time activation:** the very first submission sends an activation email to zumwohlmobil@gmail.com. Click "Activate Form" in that email; from then on every inquiry arrives. Name FormSubmit as a processor in the Datenschutzerklärung. Pass a custom \`onSubmit\` to use another service.

## Props
| Prop | Type | Default |
|---|---|---|
| \`title\` | \`string\` | \`'Anfrageformular'\` |
| \`intro\` | \`string\` | warm du-intro |
| \`initialGuests\` | \`number \\| null\` | — (from PricingTierCard; \`null\` = individual offer) |
| \`initialEventType\` | \`string\` | \`''\` |
| \`shape\` | \`'rounded' \\| 'pill'\` | \`'rounded'\` (Canva look) |
| \`privacyHref\` | \`string\` | \`'/datenschutz'\` |
| \`onSubmit\` | \`(values, recipient) => Promise<void>\` | \`sendViaFormSubmit\` |
| \`className\` | \`string\` | — |

## Usage
\`\`\`tsx
const [guests, setGuests] = useState<number | null>()

<PricingTierCard guests={60} price="400,00 €" href="#anfrage" onSelect={(t) => setGuests(t.guests)} />

<div id="anfrage">
  <InquiryForm key={String(guests)} initialGuests={guests} title="Anfrageformular Heiraterei & Feierei Special" />
</div>
\`\`\`
Use \`key\` so the form re-initialises when a different tier is clicked.
`,
  "InstagramSection": `# InstagramSection

Homepage social-proof section. It has a title, a short text, a grid of 4–6 square photos linking to Instagram, and the button "@zumwohlmobil auf Instagram folgen".

**This is a static grid on purpose.** A live feed widget loads Instagram/Meta scripts. Under German data protection law (DSGVO) that requires cookie consent before it loads. Swap in a few new photos every couple of months. That's simpler and needs no consent banner.

## Props
| Prop | Type | Default |
|---|---|---|
| \`handle\` | \`string\` | \`'zumwohlmobil'\` |
| \`title\` | \`string\` | \`'Folge uns auf Instagram'\` (du-voice) |
| \`text\` | \`string\` | \`'Lass dich von unseren letzten Events inspirieren …'\` |
| \`posts\` | \`{ src, alt, href? }[]\` | \`[]\` shows an empty state |

4 posts → 2/4 columns. 6 posts → 2/3/6 columns.
`,
  "Logo": `# Logo

Renders the official Zum Wohl Mobil SVG wordmark as an \`<img>\` (alt: "Zum Wohl Mobil"). Always use this component for branding — never recreate the logo with text, fonts, or icons.

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| \`size\` | \`'sm' \\| 'md' \\| 'lg'\` | \`'md'\` | Height: sm = 24px, md = 40px, lg = 64px. Width scales automatically. |
| \`href\` | \`string\` | — | Wraps the logo in an \`<a>\` when set. |
| \`linkLabel\` | \`string\` | \`'Zum Wohl Mobil – Startseite'\` | \`aria-label\` for the link wrapper. |
| \`className\` | \`string\` | — | Extra classes (applied to the link if present, otherwise the img). |

\`LOGO_SRC\` is also exported for raw access to the asset URL.

## Usage

\`\`\`tsx
import { Logo } from 'components/Logo'

<Logo />
<Logo size="sm" />
<Logo href="/" size="lg" />
\`\`\`

## Guidelines
- Use \`href="/"\` in headers so the logo links home.
- Don't recolor, stretch, or crop the asset; keep clear space around it.
`,
  "MobileMenuOverlay": `# MobileMenuOverlay

Menu icon button that opens a full-screen, calm pale-sage navigation overlay for mobile/tablet. Shows the logo, large uppercase Jost nav links with an active marker (sage line), and a close (X) button. Hidden at \`lg\` and above by default. The link list is centered vertically but scrolls safely when the screen is short, so the first link (START) is never clipped.

## Accessibility
- Trigger: \`aria-haspopup="dialog"\`, \`aria-expanded\`, German labels ("Menü öffnen" / "Menü schließen").
- Overlay: \`role="dialog"\`, \`aria-modal\`, focus moves to the close button, Tab/Shift+Tab are trapped, Escape closes, focus returns to the trigger. Body scroll is locked while open.
- Active link gets \`aria-current="page"\`.

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| \`links\` | \`{ label, href }[]\` | Start, Preise, Rezepte, Mietablauf, Über uns, Kontakt | Labels are rendered uppercase |
| \`activeHref\` | \`string\` | – | Matches a link \`href\` to show the active marker |
| \`logo\` | \`ReactNode\` | "ZUM WOHL MOBIL" wordmark | Pass the \`Logo\` component here |
| \`onNavigate\` | \`(link, event) => void\` | – | Menu closes automatically after click |
| \`open\` / \`defaultOpen\` / \`onOpenChange\` | | uncontrolled, \`false\` | Controlled or uncontrolled |
| \`hideOnDesktop\` | \`boolean\` | \`true\` | Adds \`lg:hidden\` |
| \`className\` | \`string\` | – | Wrapper classes |

## Usage
\`\`\`tsx
import { MobileMenuOverlay } from 'components/MobileMenuOverlay'

<header className="flex items-center justify-between px-6 py-4">
  <Logo />
  <MobileMenuOverlay activeHref="/preise" logo={<Logo />} />
</header>
\`\`\`
`,
  "NavLink": `# NavLink

Uppercase, letter-spaced Jost navigation link. The active item shows a small dot marker before the label and a full 1px underline; inactive items reveal the underline on hover. Sets \`aria-current="page"\` when active.

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| \`active\` | \`boolean\` | \`false\` | Current page — shows dot + underline |
| \`size\` | \`'sm' \\| 'md'\` | \`'md'\` | Text size / tracking |
| \`tone\` | \`'dark' \\| 'light'\` | \`'dark'\` | \`dark\` for light backgrounds, \`light\` for dark/image backgrounds |
| \`hideDot\` | \`boolean\` | \`false\` | Hide the active dot marker |
| \`href\` | \`string\` | \`'#'\` | Link target |
| ...rest | \`AnchorHTMLAttributes\` | — | Passed to the \`<a>\` (ref forwarded) |

Underline and dot use \`currentColor\`, so they follow the text color.

## Usage

\`\`\`tsx
import { NavLink } from 'components/NavLink'

<nav aria-label="Hauptnavigation">
  <ul className="flex gap-8">
    <li><NavLink href="/">Home</NavLink></li>
    <li><NavLink href="/weine" active>Weine</NavLink></li>
    <li><NavLink href="/kontakt">Kontakt</NavLink></li>
  </ul>
</nav>

<NavLink href="/" tone="light">Home</NavLink>
\`\`\`

Note: the Jost font is referenced by name; ensure it's loaded in \`index.css\` (Google Fonts) for it to render.
`,
  "PageHeader": `# PageHeader

Top-of-page section with the page's single H1 in Allura script, an optional subline in Jost, an optional pill CTA and soft watercolor/eucalyptus decoration. Use it once per page.

- **Banner** (no \`imageSrc\`): centered. Use it for Preise, Rezepte, Mietablauf, Über uns and Kontakt.
- **Hero** (with \`imageSrc\`): use it on the homepage. On desktop (\`lg+\`) the lettering and button sit on the left. The torn-edge photo fills the right ~54% and runs off the right edge of the screen, so its left and bottom tears read as intentional. Never fade the photo with a gradient. On phones and tablets it stacks lettering → button → photo, with tighter top padding so the button is visible without scrolling. Keep this order.

Decoration shows on every page and every screen size. It shrinks smoothly on phones instead of hiding, and always sits behind content:
- **Banner:** watercolor splash + garland top-left, drift wash bottom-right.
- **Hero:** one tall eucalyptus branch (\`twin\`) framing the left edge, with a pale wash and a watercolor splash pooling beneath it toward the next section. A slender branch tucks behind the photo's bottom-left corner to tie the photo to the lettering. The top-left corner stays empty so it doesn't clash with the logo and nav. Nothing sits behind the photo itself.

## Props
| Prop | Type | Default |
|---|---|---|
| \`title\` | \`string\` | — (H1) |
| \`titleImageSrc\` | \`string\` | — (lettering SVG; \`title\` becomes its alt text) |
| \`subline\` | \`ReactNode\` | — |
| \`ctaLabel\` / \`ctaHref\` | \`string\` | — / \`'/kontakt'\` |
| \`imageSrc\` / \`imageAlt\` | \`string\` | — |
| \`decorated\` | \`boolean\` | \`true\` |
| \`className\` | \`string\` | — |

## Content mapping
| Page | title | subline | CTA |
|---|---|---|---|
| Start | Mobile Bar für besondere Momente + \`titleImageSrc="https://cdn.magicpatterns.com/uploads/sJZ5DWdv9tCu4zHVNXM7fx/text_header.svg"\` | — (keep the homepage hero simple: no subline) | Jetzt anfragen + hero photo |

On the homepage, always use the official lettering SVG — don't retype the title in Allura, and don't add a subline under it.
| Preise | Unsere Preise | — | Jetzt anfragen |
| Rezepte | Unsere Getränke | Klassisch, fruchtig … | — |
| Mietablauf | So funktioniert die Miete | In 4 einfachen Schritten zu deiner eigenen Spritz-Bar. | — |
| Über uns | Wer wir sind | Leidenschaft für besondere Momente … | — |
| Kontakt | Anfrageformular | Erzähl uns von deinem Fest … | — |
`,
  "PillButton": `# PillButton

Deep sage (\`#4F6B58\`) pill-shaped primary CTA with an uppercase, letter-spaced white label and a bold arrow-right icon. Use for primary actions like booking requests ("Jetzt anfragen"). Use one per section.

## Props

| Prop | Type | Default | Description |
|---|---|---|---|
| \`children\` | \`ReactNode\` | — | Label (shown uppercase) |
| \`size\` | \`'sm' \\| 'md' \\| 'lg'\` | \`'md'\` | Height/padding/text size |
| \`showArrow\` | \`boolean\` | \`true\` | Show trailing arrow (nudges right on hover) |
| \`loading\` | \`boolean\` | \`false\` | Shows spinner in place of arrow, disables interaction |
| \`fullWidth\` | \`boolean\` | \`false\` | Stretch to container width |
| \`href\` | \`string\` | — | Renders an \`<a>\` instead of \`<button>\` |
| \`disabled\` | \`boolean\` | \`false\` | Disabled state (50% opacity) |
| \`className\` | \`string\` | — | Extra classes (merged via tailwind-merge) |

All native button/anchor attributes are passed through. Buttons default to \`type="button"\`.

## Usage

\`\`\`tsx
import { PillButton } from 'components/PillButton'

<PillButton onClick={openBooking}>Jetzt anfragen</PillButton>
<PillButton href="/buchung" size="lg">Buchung anfragen</PillButton>
<PillButton type="submit" loading={isSending}>Senden</PillButton>
\`\`\`
`,
  "PillDateInput": `# PillDateInput

Pill-shaped (fully rounded) date field for selecting the **Wunschtermin** (desired event date) in booking/inquiry forms. Wraps the native \`<input type="date">\` with a leading calendar icon; clicking anywhere opens the browser's date picker.

## Props
- \`label?: string\` – visible label (default \`"Wunschtermin"\`)
- \`value?: string\` – ISO date \`yyyy-mm-dd\`
- \`onChange?: (value: string) => void\` – receives ISO date string
- \`hint?: string\` – helper text below the field
- \`error?: string\` – error message; sets red border + \`aria-invalid\`
- \`size?: 'sm' | 'md' | 'lg'\` – default \`md\`
- \`shape?: 'pill' | 'rounded'\` – default \`pill\`; \`rounded\` matches the Canva inquiry form
- \`hideLabel?: boolean\` – screen-reader-only label
- \`required\`, \`disabled\`, \`min\`, \`max\`, \`name\`, and other native input attributes
- \`className\` (input), \`containerClassName\` (wrapper)

## Usage
\`\`\`tsx
const [date, setDate] = useState('')

<PillDateInput
  value={date}
  onChange={setDate}
  min={new Date().toISOString().slice(0, 10)}
  hint="Wann soll dein Fest stattfinden?"
  required
/>
\`\`\`

## Notes
- Forwards ref to the underlying input.
- Use \`min\` set to today to prevent past dates.
`,
  "PillInput": `# PillInput

Pill-shaped (fully rounded) form input with a label above, optional required marker, helper text and inline error message. Supports \`text\`, \`number\`, \`tel\` and \`email\`.

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| \`label\` | \`string\` | — | Visible label above the input (required) |
| \`type\` | \`'text' \\| 'number' \\| 'tel' \\| 'email'\` | \`'text'\` | Input type |
| \`required\` | \`boolean\` | \`false\` | Adds \`*\` (plus "Pflichtfeld" for screen readers) and native \`required\` |
| \`error\` | \`string\` | — | Error message; turns border red, sets \`aria-invalid\` |
| \`hint\` | \`string\` | — | Helper text shown when there is no error |
| \`shape\` | \`'pill' \\| 'rounded'\` | \`'pill'\` | \`rounded\` = 16px corners, matching the Canva inquiry form |

Styled with design tokens: \`text-text\` labels, \`border-muted-text\` border, \`border-primary\` on hover/focus, \`bg-surface\`.
| \`className\` | \`string\` | — | Classes for the outer wrapper |

All other native \`<input>\` props (\`value\`, \`onChange\`, \`placeholder\`, \`name\`, \`disabled\`, …) are forwarded. The ref is forwarded to the \`<input>\`.

## Usage

\`\`\`tsx
import { PillInput } from 'components/PillInput'

<PillInput label="Name" placeholder="Max Mustermann" />
<PillInput label="E-Mail" type="email" required />
<PillInput label="Telefon" type="tel" error="Bitte gib eine gültige Nummer ein." />
\`\`\`

## Notes
- Full width by default; constrain with a parent container.
- Number spinners are hidden for a clean pill look.
- Error text uses \`role="alert"\` and is linked via \`aria-describedby\`.
`,
  "PillSelect": `# PillSelect

Pill-shaped (fully rounded) select dropdown for choosing the event type in booking/inquiry forms. Built on a native \`<select>\` for full keyboard and mobile accessibility, with a custom chevron.

Default options: Hochzeit, Geburtstag, Firmenfeier, Jubiläum, Sonstiges (exported as \`EVENT_TYPE_OPTIONS\`).

## Props
- \`label?: string\` – visible label (default \`"Art der Veranstaltung"\`)
- \`hideLabel?: boolean\` – visually hide label (still read by screen readers)
- \`placeholder?: string\` – disabled first option (default \`"Anlass wählen"\`); pass \`""\` to omit
- \`options?: { value: string; label: string }[]\` – defaults to \`EVENT_TYPE_OPTIONS\`
- \`size?: 'sm' | 'md' | 'lg'\` – default \`md\`
- \`shape?: 'pill' | 'rounded'\` – default \`pill\`; \`rounded\` matches the Canva inquiry form
- \`required?: boolean\` – shows \`*\`; no longer set automatically by the placeholder
- \`helperText?: string\` – hint below field
- \`error?: string\` – error message, red styling, sets \`aria-invalid\`
- \`wrapperClassName?: string\` – classes for outer wrapper
- All native \`<select>\` props (\`value\`, \`onChange\`, \`name\`, \`disabled\`, \`required\`, …); ref forwarded to the \`<select>\`

## Usage
\`\`\`tsx
import { PillSelect } from 'components/PillSelect'

<PillSelect name="eventType" />

const [type, setType] = useState('')
<PillSelect value={type} onChange={(e) => setType(e.target.value)} error={!type ? 'Bitte wählen' : undefined} />
\`\`\`
`,
  "PillTextarea": `# PillTextarea

Rounded, pill-style multi-line textarea for longer message fields (contact/booking forms). Matches PillInput styling: white surface, soft stone border, large radius, focus ring.

## Props
- \`label?: string\` – label above the field (shows \`*\` when \`required\`)
- \`helperText?: string\` – hint below the field
- \`error?: string\` – error message; sets red border and \`aria-invalid\`
- \`size?: 'sm' | 'md' | 'lg'\` – default \`md\`
- \`showCount?: boolean\` – live counter; requires \`maxLength\`
- \`fullWidth?: boolean\` – default \`true\`
- \`wrapperClassName?: string\` – classes for the outer wrapper
- All native \`<textarea>\` props (\`rows\`, \`value\`, \`onChange\`, \`disabled\`, …). Forwards ref.

## Usage
\`\`\`tsx
import { PillTextarea } from 'components/PillTextarea'

<PillTextarea
  label="Ihre Nachricht"
  placeholder="Erzählen Sie uns von Ihrer Veranstaltung…"
  maxLength={500}
  showCount
  required
/>
\`\`\`
`,
  "PriceNote": `# PriceNote

Small, centered, muted line placed under the pricing grid for fine print (travel fees, VAT info).

## Props
- \`items?: string[]\` — text segments joined by a separator. Default: \`["Inkl. 50 km Anfahrt, danach 3,00 € pro km", "Alle Preise inkl. MwSt."]\`
- \`children?: ReactNode\` — custom content; overrides \`items\`.
- \`separator?: string\` — default \`·\`.
- \`align?: 'center' | 'left'\` — default \`center\`.
- \`className?: string\`

## Usage
\`\`\`tsx
<PriceNote />
<PriceNote items={['Inkl. 30 km Anfahrt', 'Alle Preise inkl. MwSt.']} />
<PriceNote>Individuelle Angebote auf Anfrage.</PriceNote>
\`\`\`
`,
  "PricingTierCard": `# PricingTierCard

Clickable pricing card for the Zum Wohl Mobil packages: people icon, uppercase guest label ("BIS 30 GÄSTE"), short divider and price. Clicking calls \`onSelect\` with the tier so the request form can be pre-filled. The custom variant reads "INDIVIDUELLES ANGEBOT" and links to a custom inquiry.

Renders a \`<button>\` by default, or an \`<a>\` when \`href\` is set (\`onSelect\` still fires).

## Props
| Prop | Type | Default | Description |
|---|---|---|---|
| \`guests\` | \`number \\| null\` | \`null\` | Max guest count. \`null\` → custom tier |
| \`price\` | \`string\` | – | e.g. \`"ab 690 €"\` |
| \`custom\` | \`boolean\` | auto | Force "Individuelles Angebot" variant |
| \`label\` | \`string\` | auto | Override label |
| \`customHint\` | \`string\` | \`"Ab 91 Gästen – jetzt anfragen"\` | Text shown instead of price on custom tier |
| \`selected\` | \`boolean\` | \`false\` | Selected styling (\`aria-pressed\`) |
| \`onSelect\` | \`(tier: { guests: number \\| null; price?: string }) => void\` | – | Pre-fill callback |
| \`href\` | \`string\` | – | Render as link, e.g. \`#anfrage\` |
| \`className\` | \`string\` | – | Extra classes (merged) |

## Usage
\`\`\`tsx
<div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
  <PricingTierCard guests={30} price="ab 690 €" href="#anfrage" onSelect={(t) => setGuests(t.guests)} />
  <PricingTierCard guests={60} price="ab 1.190 €" href="#anfrage" onSelect={(t) => setGuests(t.guests)} />
  <PricingTierCard guests={100} price="ab 1.790 €" href="#anfrage" onSelect={(t) => setGuests(t.guests)} />
  <PricingTierCard custom href="#anfrage" onSelect={() => setGuests(null)} />
</div>
\`\`\`
`,
  "ProcessStep": `# ProcessStep

Numbered step used to illustrate the Mietablauf (rental process). Renders an \`<li>\`, so always wrap steps in an \`<ol>\` (or \`<ul>\`).

## Props

| Prop | Type | Default | Description |
|---|---|---|---|
| \`step\` | \`number\` | — | Step number (badge in card/compact, "SCHRITT N" label in circle) |
| \`title\` | \`string\` | — | Step title |
| \`description\` | \`ReactNode\` | — | Supporting text (one line in circle variant) |
| \`icon\` | \`ReactNode\` | — | Optional icon (lucide-react). In circle it's auto-sized to ~32–36px |
| \`variant\` | \`'card' \\| 'compact' \\| 'circle'\` | \`'card'\` | Bordered card, inline timeline row, or soft icon circle |
| \`highlighted\` | \`boolean\` | \`false\` | Emphasizes the step (card/compact: filled badge; circle: Aperol fill, white icon) |
| \`showConnector\` | \`boolean\` | \`false\` | Line to next step (compact: vertical line; circle: dotted path) |
| \`className\` | \`string\` | — | Extra classes |

## \`circle\` variant

Centered vertical stack: circle → small "SCHRITT N" label → title → one-line description.

- **Circle:** 80px (mobile) / 96px (md+), fully round, pale sage fill (\`bg-card\`, #CBD9CD), 1px deep sage border (#5F7363), icon centered in deep sage. Pass any lucide icon — it's sized by the wrapper, no \`size\` prop needed.
- **Highlighted:** Aperol fill (\`bg-accent\`, #E67A3B), white icon, no border — use for the emotional middle step.
- **Label:** small uppercase, letter-spaced Jost in muted sage (#8A9A8C). It's hidden from screen readers; they hear the visually hidden "Schritt N:" before the title instead.
- **Title:** Jost, uppercase, letter-spaced, medium weight, deep sage.
- **Description:** Jost light, deep sage, centered, max ~16rem wide.
- **Connector:** at md+ a horizontal 2px dotted line (#5F7363, 50% opacity) runs from the circle to the next step, centered on the circle. On mobile (stacked) a short vertical dotted line sits under the description. Decorative (aria-hidden).
- Flat: no shadows or gradients. The circle scales slightly (1.04) on hover.

Recommended wrapper (the connector width assumes the \`md:gap-6\` gap). Set \`showConnector\` on every step except the last:

\`\`\`tsx
<ol className="grid gap-12 md:grid-cols-3 md:gap-6">
  <ProcessStep variant="circle" step={1} icon={<MessageCircleHeart />} title="Anfragen" description="…" showConnector />
  <ProcessStep variant="circle" step={2} icon={<Wine />} title="Anstoßen" description="…" highlighted showConnector />
  <ProcessStep variant="circle" step={3} icon={<Truck />} title="Wir bauen ab" description="…" />
</ol>
\`\`\`

## Mietablauf content

The homepage uses **3 circle steps**. Keep each description to one line:

| # | Title | Icon | Description |
|---|---|---|---|
| 1 | Anfragen | \`MessageCircleHeart\` | Wunschtermin & Gästezahl senden – wir schicken dir dein Angebot. |
| 2 | Anstoßen *(highlighted)* | \`Wine\` | Wir liefern & bauen auf, du feierst mit deinen Gästen. |
| 3 | Wir bauen ab | \`Truck\` | Nach dem Fest holen wir alles wieder ab – für dich bleibt nichts zu tun. |

Section heading (SectionHeading): script "So einfach geht's", title "So funktioniert die Miete", description "In 3 einfachen Schritten zu deiner eigenen Spritz-Bar."

## Guidelines

- Use \`circle\` for customer-facing process overviews. Use \`card\` / \`compact\` for denser or internal contexts.
- Keep descriptions to a single short line.
- Always show the Abbau (dismantling/pickup) step as part of the process.

## Other variants

\`\`\`tsx
<ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
  <ProcessStep step={1} title="Anfrage stellen" description="Wunschtermin senden." />
  <ProcessStep step={2} title="Angebot & Buchung" highlighted />
</ol>

<ol>
  <ProcessStep variant="compact" step={1} title="Anfrage" showConnector />
  <ProcessStep variant="compact" step={2} title="Buchung" />
</ol>
\`\`\`

Screen readers hear "Schritt N:" before each title.
`,
  "RecipeCard": `# RecipeCard

Drink card for the Rezepte page. It's a flat, pale sage card (32px radius, no shadow) with a photo, an optional character tag (white pill), an uppercase Jost title, a short sage divider and the ingredient list in **Bebas Neue**. Ingredient lists are the only place Bebas Neue is allowed.

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| \`title\` | \`string\` | — | Drink name |
| \`subtitle\` | \`string\` | — | Optional short description |
| \`imageSrc\` / \`imageAlt\` | \`string\` | — | Shows a glass icon when there's no image |
| \`ingredients\` | \`{ name; amount? }[]\` | — | Rendered uppercase in Bebas Neue |
| \`tag\` | \`string\` | — | e.g. Klassiker, Fruchtig, Alkoholfrei |
| \`variant\` | \`'sage' \\| 'white'\` | \`'sage'\` | \`white\` = thin sage border, for use on sage sections |
| \`loading\` | \`boolean\` | \`false\` | Skeleton |
| \`className\` | \`string\` | — | |

## Rezepte content
| Drink | Ingredients | Tag |
|---|---|---|
| Aperol Spritz | Aperol, Prosecco, Soda, Orange | Klassiker |
| Tropical Spritz | Aperol, Prosecco, Soda, Mangonektar, Mango | Fruchtig |
| Wild Berry Spritz | Aperol, Prosecco, Wild Berry Soda, Beeren | Fruchtig & spritzig |
| Virgin Spritz | Crodino, Alkoholfreier Sekt, Soda, Orange | Alkoholfrei |

Grid: \`grid gap-6 sm:grid-cols-2 lg:grid-cols-4\`. Follow it with \`<ScriptBanner variant="wash" heart text="Wähle das Getränk, das dir am besten schmeckt!" />\`.
`,
  "ScriptBanner": `# ScriptBanner

A full-width strip with one emotional line in Allura script. Use it for short moments with personality, at most once or twice per page.

- Homepage: "Aperol Spritz – unsere Spezialität" (\`variant="band"\`)
- Rezepte page footer: "Wähle das Getränk, das dir am besten schmeckt!" with \`heart\` (\`variant="wash"\`)

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| \`text\` | \`string\` | — | Keep it short (one line on desktop) |
| \`eyebrow\` | \`string\` | — | Small uppercase Jost line above |
| \`heart\` | \`boolean\` | \`false\` | Adds a small Aperol-orange ♡ (decorative) |
| \`variant\` | \`'band' \\| 'wash' \\| 'plain'\` | \`'band'\` | \`band\` = pale sage strip, \`wash\` = watercolor blot behind |
| \`as\` | \`'p' \\| 'h2' \\| 'h3'\` | \`'p'\` | Use \`h2\` when the line acts as a section title |
| \`className\` | \`string\` | — | |
`,
  "SectionHeading": `# SectionHeading

Introduces a page section with a decorative script line (Allura) above an uppercase, letter-spaced Jost title. Optional divider and supporting description.

Fonts resolve via \`--font-script\` / \`--font-body\` CSS variables, falling back to \`'Allura'\` and \`'Jost'\` — make sure both are loaded (Google Fonts) in the consuming app.

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| \`title\` | \`ReactNode\` | — | Required. Main heading text (Jost, uppercase) |
| \`script\` | \`ReactNode\` | — | Script line above the title (Allura). Decorative visually; included for screen readers inside the heading |
| \`description\` | \`ReactNode\` | — | Supporting paragraph |
| \`align\` | \`'left' \\| 'center' \\| 'right'\` | \`'center'\` | |
| \`size\` | \`'sm' \\| 'md' \\| 'lg'\` | \`'md'\` | Scales both script and title |
| \`tone\` | \`'default' \\| 'inverse'\` | \`'default'\` | Use \`inverse\` on dark/photo backgrounds |
| \`as\` | \`'h1' \\| 'h2' \\| 'h3' \\| 'h4'\` | \`'h2'\` | Semantic heading level |
| \`divider\` | \`boolean\` | \`false\` | Short rule below the title |
| \`className\`, \`id\` | \`string\` | — | |

## Usage
\`\`\`tsx
import { SectionHeading } from 'components/SectionHeading'

<SectionHeading script="Willkommen" title="Zum Wohl Mobil" />

<SectionHeading
  script="Unser Angebot"
  title="Mobile Bar für jeden Anlass"
  description="Wir bringen ausgewählte Weine direkt zu Ihrem Event."
  size="lg"
  divider
/>

<SectionHeading script="Galerie" title="Eindrücke" tone="inverse" />
\`\`\`
`,
  "SiteFooter": `# SiteFooter

Global footer on a pale sage (\`bg-card\`) surface. Three columns, which stack on mobile:
1. Logo, "Zum Wohl Mobil – Mobile Bar für besondere Momente." and an Instagram link.
2. Page links: Start, Preise, Rezepte, Mietablauf, Über uns, Kontakt.
3. Rechtliches: Impressum, Datenschutz, AGB. These pages are legally required in Germany, so always keep them.

Copyright line: "© {year} Zum Wohl Mobil. Alle Rechte vorbehalten." The year updates automatically.

## Props
| Prop | Type | Default |
|---|---|---|
| \`tagline\` | \`string\` | \`'Mobile Bar für besondere Momente.'\` |
| \`links\` / \`legalLinks\` | \`{ label, href }[]\` | see above |
| \`instagramHandle\` | \`string\` | \`'zumwohlmobil'\`. Pass \`''\` to hide it |
| \`year\` | \`number\` | current year |
| \`className\` | \`string\` | — |
`,
  "SiteHeader": `# SiteHeader

Global header for every page: Logo (links home), the six nav links with the underline-and-dot active marker (desktop, \`lg+\`), the JETZT ANFRAGEN pill CTA (\`sm+\`), and the MobileMenuOverlay (below \`lg\`). Desktop nav (logo, six links, CTA) is always visible from \`lg\` (≥1024px). Below \`lg\` it collapses into MobileMenuOverlay. Windows laptops with 125–150% display scaling often have effective widths of ~1100–1280px, so the full navigation must fit at \`lg\` — never push the switch back to \`xl\`.

To fit at 1024px the header scales fluidly: links use NavLink \`sm\` sizing with \`lg:gap-5\` (full \`md\` sizing and \`xl:gap-8\` at \`xl\`), the logo is \`h-12\` at \`lg\` and \`h-16\` at \`xl\`, the CTA is PillButton \`sm\` at \`lg\` and \`md\` sizing at \`xl\`, container padding is \`px-6 xl:px-10\`, and links are \`whitespace-nowrap\`.

Composes Logo, NavLink, PillButton and MobileMenuOverlay — don't rebuild these inline.

## Props
| Prop | Type | Default |
|---|---|---|
| \`activeHref\` | \`string\` | \`'/'\` |
| \`links\` | \`{ label, href }[]\` | Start, Preise, Rezepte, Mietablauf, Über uns, Kontakt |
| \`ctaLabel\` | \`string\` | \`'Jetzt anfragen'\` (rendered uppercase) |
| \`ctaHref\` | \`string\` | \`'/kontakt'\` |
| \`sticky\` | \`boolean\` | \`true\` |
| \`className\` | \`string\` | — |

## Usage
\`\`\`tsx
<SiteHeader activeHref="/preise" />
\`\`\`
`,
  "TornEdgeImage": `# TornEdgeImage

An image clipped with a soft, deterministic torn-paper edge. Used for botanical/collage photo moments. An optional cream paper fringe sits behind the photo for a real torn-paper look. Includes loading and error states.

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| \`src\` | \`string\` | — | Image URL |
| \`alt\` | \`string\` | — | Alt text (\`""\` if decorative) |
| \`edges\` | \`'all' \\| 'top' \\| 'bottom' \\| 'top-bottom' \\| 'left-right'\` | \`'all'\` | Which edges are torn |
| \`roughness\` | \`'soft' \\| 'medium' \\| 'rough'\` | \`'medium'\` | Depth of the tear |
| \`seed\` | \`number\` | \`7\` | Changes the tear pattern (stable across renders) |
| \`paper\` | \`boolean\` | \`true\` | Cream paper fringe behind the tear |
| \`aspectRatio\` | \`string\` | \`'4 / 3'\` | CSS aspect ratio |
| \`rotate\` | \`number\` | \`0\` | Tilt in degrees for collages |
| \`shadow\` | \`boolean\` | \`true\` | Soft drop shadow following the torn shape |
| \`caption\` | \`ReactNode\` | — | Italic caption below |
| \`className\` | \`string\` | — | Extra classes on the \`<figure>\` |

Width follows the parent; height comes from \`aspectRatio\`.

## Usage

\`\`\`tsx
import { TornEdgeImage } from 'components/TornEdgeImage'

<TornEdgeImage src={url} alt="Wildflowers" />

<TornEdgeImage src={url} alt="Vineyard" edges="top-bottom" roughness="rough" aspectRatio="21 / 9" />

<div className="w-60">
  <TornEdgeImage src={url} alt="Herbs" rotate={-3} seed={3} caption="Aus dem Garten" />
</div>
\`\`\`

Use different \`seed\` values when several appear side by side so the tears don't repeat.
`,
  "WatercolorBackground": `# WatercolorBackground

A full-width section wrapper that places the real watercolor blots (**WatercolorBlot**) and eucalyptus sprigs (**BotanicalDecoration**) in the background. Every composition puts a blot underneath and lays a sprig over it, so the leaves look painted onto the wash. Decorations sit behind the content (\`-z-10\`), use \`aria-hidden\`, and ignore pointer events. They are flat: no shadows and no gradients.

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| \`layout\` | \`'hero' \\| 'corners' \\| 'left' \\| 'right' \\| 'blots-only' \\| 'none'\` | \`'corners'\` | Preset arrangement (see below) |
| \`mobile\` | \`'scale' \\| 'hide'\` | \`'scale'\` | \`scale\` shrinks pieces to about 55% on phones. \`hide\` removes them below \`md\` |
| \`mirror\` | \`boolean\` | \`false\` | Flips the whole composition left ↔ right. For example, \`corners\` + \`mirror\` puts the pairings at top-right and bottom-left |
| \`mirrorVertical\` | \`boolean\` | \`false\` | Flips the whole composition top ↔ bottom |
| \`botanicalOpacity\` | \`number\` | \`1\` | Fades every sprig in the layout (multiplier, 0 to 1) |
| \`blotOpacity\` | \`number\` | \`1\` | Fades every blot in the layout (multiplier, 0 to 1) |
| \`paperColor\` | \`string\` | \`'var(--background)'\` | Base color |
| \`as\` | \`'div' \\| 'section' \\| 'header' \\| 'footer' \\| 'main'\` | \`'div'\` | Wrapper element |
| \`className\` | \`string\` | – | Wrapper classes |
| \`contentClassName\` | \`string\` | – | Content layer classes |
| \`children\` | \`ReactNode\` | – | Section content |

## Layouts
- \`hero\`: splash blot + garland at top-left, drift blot + corner sprig at bottom-right. Use it only for the opening section.
- \`corners\`: a drift blot + eucalyptus at top-left, and a splash blot + faded dark sprig at bottom-right. A general-purpose section background.
- \`left\`: a drift blot + the upright twin branch. \`right\`: a splash blot + the slender branch. Use these for quieter sections such as the process steps or the form.
- \`blots-only\`: washes with no leaves. A breather between busier sections.
- \`none\`: a plain paper background.

## Usage
\`\`\`tsx
<WatercolorBackground as="section" layout="hero">
  <div className="mx-auto max-w-5xl px-6 py-24">…</div>
</WatercolorBackground>
\`\`\`

## Guidelines
- Use them sparingly. Don't give every section leaves. Alternate \`corners\` / \`left\` / \`right\` / \`blots-only\` / \`none\` down the page.
- Toggle \`mirror\` on alternating sections that share a layout, so they don't look repeated.
- Behind text-heavy sections, lower \`botanicalOpacity\` (about 0.5) instead of removing the leaves.
- Use \`mobile="hide"\` behind dense text, such as the inquiry form or pricing.
- For a one-off placement, use \`WatercolorBlot\` and \`BotanicalDecoration\` directly inside a \`relative isolate\` parent.
`,
  "WatercolorBlot": `# WatercolorBlot

Abstract liquid watercolor blob shapes in pale sage-grey (real brand SVG assets — never redraw, recolour or substitute). The companion to **BotanicalDecoration**: blobs are the soft "ground", sprigs sit on top. Decorative only (\`aria-hidden\`, \`pointer-events-none\`). Absolute positions sit behind content (negative z-index), so give the parent \`relative isolate\` (and usually \`overflow-hidden\`).

For whole-section backgrounds, **WatercolorBackground** arranges washes for you; use WatercolorBlot for one-off or custom placements.

## Variants
- \`splash\` — wide blob with layered pools and splatter dots. Hero / behind wide content.
- \`wash\` — very pale, square-ish wash. A quiet base layer under other blobs or text.
- \`drift\` — diagonal splash with droplets. Corners and section edges.

All variants are transparent SVGs. Only add new blot assets if they have a transparent background.

Asset URLs are exported as \`WATERCOLOR_BLOT_SOURCES\`.

## Props
| Prop | Type | Default | Notes |
|---|---|---|---|
| \`variant\` | see above | \`'splash'\` | Blob shape |
| \`position\` | \`'top-left' \\| 'top-right' \\| 'bottom-left' \\| 'bottom-right' \\| 'center' \\| 'inline'\` | \`'inline'\` | Non-inline values are \`absolute\` behind content |
| \`size\` | \`number\` | \`360\` | Width in px |
| \`rotate\` | \`number\` | \`0\` | Degrees |
| \`flip\` / \`flipVertical\` | \`boolean\` | \`false\` | Mirror — combine with rotate so one asset reads as many blobs |
| \`opacity\` | \`number\` | \`1\` | Transparency 0–1 (clamped). Lower behind dense text |
| \`layer\` | \`number\` | \`0\` | 0–9 stacking order for overlapping blobs; higher sits on top, all stay behind content |
| \`blend\` | \`boolean\` | \`true\` | Multiply blend so overlaps deepen like real pigment |
| \`mobileScale\` | \`number\` | \`0.55\` | Smallest scale on phones (width shrinks smoothly from \`size\` down to \`size × mobileScale\`). \`1\` = fixed size |
| \`className\` | \`string\` | — | e.g. \`!top-4 !left-8\` to nudge offsets |

## Stacking & mixing
\`\`\`tsx
<section className="relative isolate overflow-hidden">
  <WatercolorBlot variant="wash" position="center" size={420} layer={0} />
  <WatercolorBlot variant="splash" position="center" size={300} layer={1} rotate={20} opacity={0.7} />
  <BotanicalDecoration variant="corner" position="top-left" size={160} />
  <h2>…</h2>
</section>
\`\`\`

## Guidelines
- Use sparingly — 1–3 blobs per section, not every section.
- Keep visible on mobile. Blots shrink automatically via \`mobileScale\`, so don't hide them.
- Never place over text; content always sits above blobs.
`
};

export const componentRegistry: ComponentPreviewModule[] = [
__AddOnPricePanelPreviews,
__AddOnPriceRowPreviews,
__BotanicalDecorationPreviews,
__ConsentCheckboxPreviews,
__DownloadCalloutPreviews,
__FormStatusMessagePreviews,
__ImageCarouselPreviews,
__InfoTextBlockPreviews,
__InquiryFormPreviews,
__InstagramSectionPreviews,
__LogoPreviews,
__MobileMenuOverlayPreviews,
__NavLinkPreviews,
__PageHeaderPreviews,
__PillButtonPreviews,
__PillDateInputPreviews,
__PillInputPreviews,
__PillSelectPreviews,
__PillTextareaPreviews,
__PriceNotePreviews,
__PricingTierCardPreviews,
__ProcessStepPreviews,
__RecipeCardPreviews,
__ScriptBannerPreviews,
__SectionHeadingPreviews,
__SiteFooterPreviews,
__SiteHeaderPreviews,
__TornEdgeImagePreviews,
__WatercolorBackgroundPreviews,
__WatercolorBlotPreviews].

filter((m) => m && m.componentName).
map((m) => ({ ...m, contextMd: __contextMd[m.componentName] ?? m.contextMd })).
sort((a, b) => a.componentName.localeCompare(b.componentName));