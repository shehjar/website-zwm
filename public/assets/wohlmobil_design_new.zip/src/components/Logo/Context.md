# Logo

Renders the official Zum Wohl Mobil SVG wordmark as an `<img>` (alt: "Zum Wohl Mobil"). Always use this component for branding — never recreate the logo with text, fonts, or icons.

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `size` | `'sm' \| 'md' \| 'lg'` | `'md'` | Height: sm = 24px, md = 40px, lg = 64px. Width scales automatically. |
| `href` | `string` | — | Wraps the logo in an `<a>` when set. |
| `linkLabel` | `string` | `'Zum Wohl Mobil – Startseite'` | `aria-label` for the link wrapper. |
| `className` | `string` | — | Extra classes (applied to the link if present, otherwise the img). |

`LOGO_SRC` is also exported for raw access to the asset URL.

## Usage

```tsx
import { Logo } from 'components/Logo'

<Logo />
<Logo size="sm" />
<Logo href="/" size="lg" />
```

## Guidelines
- Use `href="/"` in headers so the logo links home.
- Don't recolor, stretch, or crop the asset; keep clear space around it.
