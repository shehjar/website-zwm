import { Logo } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'Logo',
  importPath: 'components/Logo',
  previews: [
  {
    name: 'Default',
    description: 'Medium wordmark',
    render: () => <Logo />
  },
  {
    name: 'Sizes',
    description: 'Small, medium and large',
    render: () =>
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 32 }}>
          <Logo size="sm" />
          <Logo size="md" />
          <Logo size="lg" />
        </div>

  },
  {
    name: 'As link',
    description: 'Wrapped in a link to the homepage',
    render: () => <Logo href="/" size="md" />
  }]

};

export default previews;