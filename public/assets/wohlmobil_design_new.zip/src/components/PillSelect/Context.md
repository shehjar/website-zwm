# PillSelect

Pill-shaped (fully rounded) select dropdown for choosing the event type in booking/inquiry forms. Built on a native `<select>` for full keyboard and mobile accessibility, with a custom chevron.

Default options: Hochzeit, Geburtstag, Firmenfeier, Jubiläum, Sonstiges (exported as `EVENT_TYPE_OPTIONS`).

## Props
- `label?: string` – visible label (default `"Art der Veranstaltung"`)
- `hideLabel?: boolean` – visually hide label (still read by screen readers)
- `placeholder?: string` – disabled first option (default `"Anlass wählen"`); pass `""` to omit
- `options?: { value: string; label: string }[]` – defaults to `EVENT_TYPE_OPTIONS`
- `size?: 'sm' | 'md' | 'lg'` – default `md`
- `shape?: 'pill' | 'rounded'` – default `pill`; `rounded` matches the Canva inquiry form
- `required?: boolean` – shows `*`; no longer set automatically by the placeholder
- `helperText?: string` – hint below field
- `error?: string` – error message, red styling, sets `aria-invalid`
- `wrapperClassName?: string` – classes for outer wrapper
- All native `<select>` props (`value`, `onChange`, `name`, `disabled`, `required`, …); ref forwarded to the `<select>`

## Usage
```tsx
import { PillSelect } from 'components/PillSelect'

<PillSelect name="eventType" />

const [type, setType] = useState('')
<PillSelect value={type} onChange={(e) => setType(e.target.value)} error={!type ? 'Bitte wählen' : undefined} />
```
