import React, { useState } from 'react';
import { PillSelect } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

function ControlledExample() {
  const [value, setValue] = useState('hochzeit');
  return (
    <div className="w-80">
      <PillSelect
        value={value}
        onChange={(e) => setValue(e.target.value)}
        helperText={`Ausgewählt: ${value}`} />
      
    </div>);

}

const previews: ComponentPreviewModule = {
  componentName: 'PillSelect',
  importPath: 'components/PillSelect',
  previews: [
  {
    name: 'Default',
    description: 'Event type select with placeholder',
    render: () =>
    <div className="w-80">
          <PillSelect name="eventType" />
        </div>

  },
  {
    name: 'Controlled',
    description: 'Controlled value with helper text',
    render: () => <ControlledExample />
  },
  {
    name: 'Sizes',
    description: 'Small, medium and large pills',
    render: () =>
    <div className="flex w-80 flex-col gap-4">
          <PillSelect size="sm" hideLabel />
          <PillSelect size="md" hideLabel />
          <PillSelect size="lg" hideLabel />
        </div>

  },
  {
    name: 'Error',
    description: 'Validation error state',
    render: () =>
    <div className="w-80">
          <PillSelect error="Bitte wählen Sie einen Anlass." />
        </div>

  },
  {
    name: 'Disabled',
    description: 'Disabled state',
    render: () =>
    <div className="w-80">
          <PillSelect disabled defaultValue="firmenfeier" />
        </div>

  }]

};

export default previews;