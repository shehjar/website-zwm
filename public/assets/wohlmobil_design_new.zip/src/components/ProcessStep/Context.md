# ProcessStep

Numbered step used to illustrate the Mietablauf (rental process). Renders an `<li>`, so always wrap steps in an `<ol>` (or `<ul>`).

## Props

| Prop | Type | Default | Description |
|---|---|---|---|
| `step` | `number` | — | Step number (badge in card/compact, "SCHRITT N" label in circle) |
| `title` | `string` | — | Step title |
| `description` | `ReactNode` | — | Supporting text (one line in circle variant) |
| `icon` | `ReactNode` | — | Optional icon (lucide-react). In circle it's auto-sized to ~32–36px |
| `variant` | `'card' \| 'compact' \| 'circle'` | `'card'` | Bordered card, inline timeline row, or soft icon circle |
| `highlighted` | `boolean` | `false` | Emphasizes the step (card/compact: filled badge; circle: Aperol fill, white icon) |
| `showConnector` | `boolean` | `false` | Line to next step (compact: vertical line; circle: dotted path) |
| `className` | `string` | — | Extra classes |

## `circle` variant

Centered vertical stack: circle → small "SCHRITT N" label → title → one-line description.

- **Circle:** 80px (mobile) / 96px (md+), fully round, pale sage fill (`bg-card`, #CBD9CD), 1px deep sage border (#5F7363), icon centered in deep sage. Pass any lucide icon — it's sized by the wrapper, no `size` prop needed.
- **Highlighted:** Aperol fill (`bg-accent`, #E67A3B), white icon, no border — use for the emotional middle step.
- **Label:** small uppercase, letter-spaced Jost in muted sage (#8A9A8C). It's hidden from screen readers; they hear the visually hidden "Schritt N:" before the title instead.
- **Title:** Jost, uppercase, letter-spaced, medium weight, deep sage.
- **Description:** Jost light, deep sage, centered, max ~16rem wide.
- **Connector:** at md+ a horizontal 2px dotted line (#5F7363, 50% opacity) runs from the circle to the next step, centered on the circle. On mobile (stacked) a short vertical dotted line sits under the description. Decorative (aria-hidden).
- Flat: no shadows or gradients. The circle scales slightly (1.04) on hover.

Recommended wrapper (the connector width assumes the `md:gap-6` gap). Set `showConnector` on every step except the last:

```tsx
<ol className="grid gap-12 md:grid-cols-3 md:gap-6">
  <ProcessStep variant="circle" step={1} icon={<MessageCircleHeart />} title="Anfragen" description="…" showConnector />
  <ProcessStep variant="circle" step={2} icon={<Wine />} title="Anstoßen" description="…" highlighted showConnector />
  <ProcessStep variant="circle" step={3} icon={<Truck />} title="Wir bauen ab" description="…" />
</ol>
```

## Mietablauf content

The homepage uses **3 circle steps**. Keep each description to one line:

| # | Title | Icon | Description |
|---|---|---|---|
| 1 | Anfragen | `MessageCircleHeart` | Wunschtermin & Gästezahl senden – wir schicken dir dein Angebot. |
| 2 | Anstoßen *(highlighted)* | `Wine` | Wir liefern & bauen auf, du feierst mit deinen Gästen. |
| 3 | Wir bauen ab | `Truck` | Nach dem Fest holen wir alles wieder ab – für dich bleibt nichts zu tun. |

Section heading (SectionHeading): script "So einfach geht's", title "So funktioniert die Miete", description "In 3 einfachen Schritten zu deiner eigenen Spritz-Bar."

## Guidelines

- Use `circle` for customer-facing process overviews. Use `card` / `compact` for denser or internal contexts.
- Keep descriptions to a single short line.
- Always show the Abbau (dismantling/pickup) step as part of the process.

## Other variants

```tsx
<ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
  <ProcessStep step={1} title="Anfrage stellen" description="Wunschtermin senden." />
  <ProcessStep step={2} title="Angebot & Buchung" highlighted />
</ol>

<ol>
  <ProcessStep variant="compact" step={1} title="Anfrage" showConnector />
  <ProcessStep variant="compact" step={2} title="Buchung" />
</ol>
```

Screen readers hear "Schritt N:" before each title.
