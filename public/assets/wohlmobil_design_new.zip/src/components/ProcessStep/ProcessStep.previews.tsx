import {
  MessageSquareIcon,
  CalendarCheckIcon,
  TruckIcon,
  PartyPopperIcon,
  MessageCircleHeartIcon,
  WineIcon } from
'lucide-react';
import { ProcessStep } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const steps = [
{ title: 'Anfrage stellen', description: 'Wunschtermin und Anlass über das Formular senden.', icon: <MessageSquareIcon size={20} /> },
{ title: 'Angebot & Buchung', description: 'Wir melden uns mit einem individuellen Angebot.', icon: <CalendarCheckIcon size={20} /> },
{ title: 'Abholung oder Lieferung', description: 'Wagen abholen oder bequem liefern lassen.', icon: <TruckIcon size={20} /> },
{ title: 'Feiern & Rückgabe', description: 'Genießen Sie Ihr Fest – danach geben Sie den Wagen zurück.', icon: <PartyPopperIcon size={20} /> }];


const circleSteps = [
{ title: 'Anfragen', description: 'Wunschtermin & Gästezahl senden – wir schicken dir dein Angebot.', icon: <MessageCircleHeartIcon /> },
{ title: 'Anstoßen', description: 'Wir liefern & bauen auf, du feierst mit deinen Gästen.', icon: <WineIcon /> },
{ title: 'Wir bauen ab', description: 'Nach dem Fest holen wir alles wieder ab – für dich bleibt nichts zu tun.', icon: <TruckIcon /> }];


const previews: ComponentPreviewModule = {
  componentName: 'ProcessStep',
  importPath: 'components/ProcessStep',
  previews: [
  {
    name: 'Mietablauf circles',
    description: 'Circle variant: 3 soft icon circles joined by a dotted path, middle step highlighted',
    render: () =>
    <ol className="grid w-full max-w-5xl gap-12 md:grid-cols-3 md:gap-6">
          {circleSteps.map((s, i) =>
      <ProcessStep
        key={s.title}
        variant="circle"
        step={i + 1}
        title={s.title}
        description={s.description}
        icon={s.icon}
        highlighted={i === 1}
        showConnector={i < circleSteps.length - 1} />

      )}
        </ol>

  },
  {
    name: 'Single circle',
    description: 'Circle variant, default (pale sage) state',
    render: () =>
    <ol className="w-72">
          <ProcessStep variant="circle" step={1} title={circleSteps[0].title} description={circleSteps[0].description} icon={circleSteps[0].icon} />
        </ol>

  },
  {
    name: 'Single card',
    description: 'Default card variant',
    render: () =>
    <ul className="w-72">
          <ProcessStep step={1} title={steps[0].title} description={steps[0].description} icon={steps[0].icon} />
        </ul>

  },
  {
    name: 'Mietablauf grid',
    description: 'Four-step rental process with the second step highlighted',
    render: () =>
    <ol className="grid w-full max-w-5xl grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((s, i) =>
      <ProcessStep key={s.title} step={i + 1} title={s.title} description={s.description} icon={s.icon} highlighted={i === 1} />
      )}
        </ol>

  },
  {
    name: 'Compact timeline',
    description: 'Compact variant with connector lines',
    render: () =>
    <ol className="w-full max-w-md">
          {steps.map((s, i) =>
      <ProcessStep
        key={s.title}
        variant="compact"
        step={i + 1}
        title={s.title}
        description={s.description}
        showConnector={i < steps.length - 1}
        highlighted={i === 0} />

      )}
        </ol>

  }]

};

export default previews;