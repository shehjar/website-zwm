# PillButton

Deep sage (`#4F6B58`) pill-shaped primary CTA with an uppercase, letter-spaced white label and a bold arrow-right icon. Use for primary actions like booking requests ("Jetzt anfragen"). Use one per section.

## Props

| Prop | Type | Default | Description |
|---|---|---|---|
| `children` | `ReactNode` | — | Label (shown uppercase) |
| `size` | `'sm' \| 'md' \| 'lg'` | `'md'` | Height/padding/text size |
| `showArrow` | `boolean` | `true` | Show trailing arrow (nudges right on hover) |
| `loading` | `boolean` | `false` | Shows spinner in place of arrow, disables interaction |
| `fullWidth` | `boolean` | `false` | Stretch to container width |
| `href` | `string` | — | Renders an `<a>` instead of `<button>` |
| `disabled` | `boolean` | `false` | Disabled state (50% opacity) |
| `className` | `string` | — | Extra classes (merged via tailwind-merge) |

All native button/anchor attributes are passed through. Buttons default to `type="button"`.

## Usage

```tsx
import { PillButton } from 'components/PillButton'

<PillButton onClick={openBooking}>Jetzt anfragen</PillButton>
<PillButton href="/buchung" size="lg">Buchung anfragen</PillButton>
<PillButton type="submit" loading={isSending}>Senden</PillButton>
```
