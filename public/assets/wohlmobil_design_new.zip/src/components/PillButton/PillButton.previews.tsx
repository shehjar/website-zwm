import { PillButton } from './index';
import type { ComponentPreviewModule } from '../previewTypes';

const previews: ComponentPreviewModule = {
  componentName: 'PillButton',
  importPath: 'components/PillButton',
  previews: [
  {
    name: 'Default',
    description: 'Primary booking CTA with arrow icon',
    render: () => <PillButton>Jetzt anfragen</PillButton>
  },
  {
    name: 'Sizes',
    description: 'Small, medium and large sizes',
    render: () =>
    <div className="flex flex-wrap items-center gap-4">
          <PillButton size="sm">Anfragen</PillButton>
          <PillButton size="md">Anfragen</PillButton>
          <PillButton size="lg">Anfragen</PillButton>
        </div>

  },
  {
    name: 'As link',
    description: 'Rendered as an anchor via href',
    render: () => <PillButton href="#booking">Buchung anfragen</PillButton>
  },
  {
    name: 'States',
    description: 'Loading, disabled and without arrow',
    render: () =>
    <div className="flex flex-wrap items-center gap-4">
          <PillButton loading>Wird gesendet</PillButton>
          <PillButton disabled>Nicht verfügbar</PillButton>
          <PillButton showArrow={false}>Mehr erfahren</PillButton>
        </div>

  },
  {
    name: 'Full width',
    description: 'Stretches to its container',
    render: () =>
    <div className="w-80">
          <PillButton fullWidth>Termin anfragen</PillButton>
        </div>

  }]

};

export default previews;